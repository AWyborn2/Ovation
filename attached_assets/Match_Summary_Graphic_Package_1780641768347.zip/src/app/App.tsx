import { useState, useRef, useCallback } from "react";
import { MatchData, defaultMatchData } from "./components/types";
import { SquareCard } from "./components/SquareCard";
import { PortraitCard } from "./components/PortraitCard";
import { StoriesCard } from "./components/StoriesCard";
import { MatchForm } from "./components/MatchForm";
import { Download, Play, Square, Smartphone, Monitor } from "lucide-react";

type CardFormat = "square" | "portrait" | "stories";

const FORMAT_CONFIGS = {
  square: { label: "Square", icon: Square, width: 1080, height: 1080, aspect: "1 / 1", desc: "1080 × 1080 · Instagram / Facebook" },
  portrait: { label: "Portrait", icon: Monitor, width: 1080, height: 1350, aspect: "4 / 5", desc: "1080 × 1350 · Instagram Portrait" },
  stories: { label: "Stories / TikTok", icon: Smartphone, width: 1080, height: 1920, aspect: "9 / 16", desc: "1080 × 1920 · Stories · Reels · TikTok" },
};

function ScaledPreview({
  children,
  nativeWidth,
  nativeHeight,
  maxHeight,
}: {
  children: React.ReactNode;
  nativeWidth: number;
  nativeHeight: number;
  maxHeight: number;
}) {
  const scale = maxHeight / nativeHeight;
  const displayWidth = nativeWidth * scale;

  return (
    <div
      style={{
        width: displayWidth,
        height: maxHeight,
        position: "relative",
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: nativeWidth,
          height: nativeHeight,
          transform: `scale(${scale})`,
          transformOrigin: "top left",
          position: "absolute",
          top: 0,
          left: 0,
        }}
      >
        {children}
      </div>
    </div>
  );
}

function ExportHint({ format }: { format: CardFormat }) {
  const cfg = FORMAT_CONFIGS[format];
  return (
    <div
      style={{
        background: "rgba(30,64,175,0.15)",
        border: "1px solid rgba(30,64,175,0.3)",
        borderRadius: 6,
        padding: "10px 14px",
        fontSize: 12,
        color: "#93c5fd",
        fontFamily: "'Inter', sans-serif",
        lineHeight: 1.6,
      }}
    >
      <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 13, marginBottom: 4, letterSpacing: "0.04em" }}>
        EXPORT GUIDE
      </div>
      <div style={{ color: "#8fa5cc" }}>
        This card renders at native <strong style={{ color: "#c8d6ef" }}>{cfg.width} × {cfg.height}px</strong>.
        To export at full resolution:
      </div>
      <ol style={{ marginTop: 6, paddingLeft: 16, color: "#8fa5cc", display: "flex", flexDirection: "column", gap: 3 }}>
        <li>Right-click the card → <em>Inspect Element</em></li>
        <li>Find <code style={{ background: "rgba(255,255,255,0.1)", padding: "1px 4px", borderRadius: 3 }}>id=&quot;card-{format}&quot;</code></li>
        <li>Use browser screenshot or a tool like <strong style={{ color: "#c8d6ef" }}>html2canvas</strong> / <strong style={{ color: "#c8d6ef" }}>Puppeteer</strong></li>
        <li>Or use <strong style={{ color: "#c8d6ef" }}>browser zoom 100%</strong> and screenshot the preview at full scroll</li>
      </ol>
    </div>
  );
}

export default function App() {
  const [matchData, setMatchData] = useState<MatchData>(defaultMatchData);
  const [activeFormat, setActiveFormat] = useState<CardFormat>("square");
  const [storiesKey, setStoriesKey] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const replayStories = useCallback(() => {
    setStoriesKey((k) => k + 1);
  }, []);

  const cfg = FORMAT_CONFIGS[activeFormat];
  const previewMaxHeight = 680;

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        background: "#080d1c",
        display: "flex",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Sidebar: form */}
      <div
        style={{
          width: sidebarOpen ? 320 : 0,
          minWidth: sidebarOpen ? 320 : 0,
          height: "100%",
          background: "#0d1528",
          borderRight: "1px solid rgba(255,255,255,0.07)",
          overflow: "hidden",
          transition: "width 0.3s ease, min-width 0.3s ease",
          flexShrink: 0,
        }}
      >
        <MatchForm data={matchData} onChange={setMatchData} />
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Top bar */}
        <div
          style={{
            height: 56,
            background: "#0d1528",
            borderBottom: "1px solid rgba(255,255,255,0.07)",
            display: "flex",
            alignItems: "center",
            padding: "0 20px",
            gap: 16,
            flexShrink: 0,
          }}
        >
          {/* Toggle sidebar */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 5,
              padding: "6px 10px",
              color: "#8fa5cc",
              cursor: "pointer",
              fontSize: 11,
              letterSpacing: "0.05em",
              fontFamily: "'Inter', sans-serif",
            }}
          >
            {sidebarOpen ? "◀ HIDE" : "▶ DATA"}
          </button>

          {/* App title */}
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "#f59e0b",
                boxShadow: "0 0 8px #f59e0b",
              }}
            />
            <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 16, color: "#ffffff", letterSpacing: "0.06em" }}>
              CRICKET SOCIAL CARDS
            </div>
          </div>

          {/* Format tabs */}
          <div style={{ display: "flex", gap: 4, marginLeft: "auto" }}>
            {(Object.entries(FORMAT_CONFIGS) as [CardFormat, typeof FORMAT_CONFIGS[CardFormat]][]).map(([key, cfg]) => {
              const Icon = cfg.icon;
              const active = activeFormat === key;
              return (
                <button
                  key={key}
                  onClick={() => setActiveFormat(key)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "6px 14px",
                    borderRadius: 5,
                    border: active ? "1px solid rgba(245,158,11,0.5)" : "1px solid rgba(255,255,255,0.1)",
                    background: active ? "rgba(245,158,11,0.15)" : "rgba(255,255,255,0.03)",
                    color: active ? "#f59e0b" : "#8fa5cc",
                    cursor: "pointer",
                    fontSize: 12,
                    fontFamily: "'Inter', sans-serif",
                    transition: "all 0.2s",
                  }}
                >
                  <Icon size={13} />
                  {cfg.label}
                </button>
              );
            })}
          </div>

          {/* Stories replay */}
          {activeFormat === "stories" && (
            <button
              onClick={replayStories}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "6px 14px",
                borderRadius: 5,
                border: "1px solid rgba(245,158,11,0.4)",
                background: "rgba(245,158,11,0.1)",
                color: "#f59e0b",
                cursor: "pointer",
                fontSize: 12,
                fontFamily: "'Inter', sans-serif",
              }}
            >
              <Play size={12} fill="#f59e0b" /> Replay
            </button>
          )}
        </div>

        {/* Preview area */}
        <div
          style={{
            flex: 1,
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            padding: "28px 24px",
            gap: 32,
            overflowY: "auto",
            overflowX: "hidden",
          }}
        >
          {/* Card preview */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
            {/* Format badge */}
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div
                style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontSize: 13,
                  color: "#f59e0b",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                }}
              >
                {cfg.label}
              </div>
              <div style={{ fontSize: 11, color: "#5a7099", fontFamily: "'Inter', sans-serif" }}>
                {cfg.desc}
              </div>
            </div>

            {/* Card with border */}
            <div
              style={{
                border: "2px solid rgba(255,255,255,0.08)",
                borderRadius: 8,
                overflow: "hidden",
                boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
              }}
            >
              <ScaledPreview
                nativeWidth={cfg.width}
                nativeHeight={cfg.height}
                maxHeight={previewMaxHeight}
              >
                {activeFormat === "square" && <SquareCard data={matchData} />}
                {activeFormat === "portrait" && <PortraitCard data={matchData} />}
                {activeFormat === "stories" && <StoriesCard key={storiesKey} data={matchData} isPlaying />}
              </ScaledPreview>
            </div>

            {/* Dimensions label */}
            <div style={{ fontSize: 11, color: "#3d5070", fontFamily: "'Inter', sans-serif" }}>
              Rendered at {cfg.width} × {cfg.height}px · Scaled for preview
            </div>
          </div>

          {/* Right panel */}
          <div style={{ width: 260, flexShrink: 0, paddingTop: 40, display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Team color swatches */}
            <div
              style={{
                background: "#0d1528",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 8,
                padding: "14px 16px",
              }}
            >
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 12, color: "#8fa5cc", letterSpacing: "0.08em", marginBottom: 12 }}>
                COLOR SCHEME
              </div>
              {[
                { label: matchData.club.name, primary: matchData.club.primaryColor, secondary: matchData.club.secondaryColor },
                { label: matchData.opposition.name, primary: matchData.opposition.primaryColor, secondary: matchData.opposition.secondaryColor },
              ].map((team) => (
                <div key={team.label} style={{ marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: "#5a7099", marginBottom: 5, fontFamily: "'Inter', sans-serif" }}>{team.label}</div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <div
                      style={{ flex: 1, height: 24, borderRadius: 4, background: team.primary, border: "1px solid rgba(255,255,255,0.1)" }}
                      title={team.primary}
                    />
                    <div
                      style={{ flex: 1, height: 24, borderRadius: 4, background: team.secondary, border: "1px solid rgba(255,255,255,0.1)" }}
                      title={team.secondary}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Match summary */}
            <div
              style={{
                background: "#0d1528",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 8,
                padding: "14px 16px",
              }}
            >
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 12, color: "#8fa5cc", letterSpacing: "0.08em", marginBottom: 10 }}>
                MATCH OVERVIEW
              </div>
              <div style={{ fontSize: 12, color: "#c8d6ef", marginBottom: 4, fontFamily: "'Inter', sans-serif" }}>{matchData.matchTitle}</div>
              <div style={{ fontSize: 11, color: "#5a7099", marginBottom: 8, fontFamily: "'Inter', sans-serif" }}>{matchData.date} · {matchData.venue}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {matchData.innings.map((inn, i) => {
                  const team = inn.teamKey === "club" ? matchData.club : matchData.opposition;
                  return (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div style={{ width: 8, height: 8, borderRadius: "50%", background: team.primaryColor, flexShrink: 0 }} />
                        <div style={{ fontSize: 11, color: "#8fa5cc", fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700 }}>
                          {team.shortName} {inn.inningsNum === 2 ? "2nd" : "1st"}
                        </div>
                      </div>
                      <div style={{ fontSize: 12, color: "#e8f0ff", fontFamily: "'Oswald', sans-serif", fontWeight: 600 }}>
                        {inn.wickets}/{inn.totalRuns}{inn.declared ? "d" : ""}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div
                style={{
                  marginTop: 10,
                  padding: "6px 10px",
                  background: matchData.resultWinner === "club" ? `${matchData.club.primaryColor}33` : `${matchData.opposition.primaryColor}33`,
                  borderRadius: 4,
                  fontSize: 11,
                  color: "#e8f0ff",
                  fontFamily: "'Inter', sans-serif",
                  textAlign: "center",
                }}
              >
                {matchData.result}
              </div>
            </div>

            <ExportHint format={activeFormat} />

            {/* Card format thumbnails */}
            <div
              style={{
                background: "#0d1528",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 8,
                padding: "14px 16px",
              }}
            >
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 12, color: "#8fa5cc", letterSpacing: "0.08em", marginBottom: 12 }}>
                ALL FORMATS
              </div>
              <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
                {(Object.entries(FORMAT_CONFIGS) as [CardFormat, typeof FORMAT_CONFIGS[CardFormat]][]).map(([key, c]) => {
                  const active = activeFormat === key;
                  const w = key === "square" ? 40 : key === "portrait" ? 36 : 28;
                  const h = key === "square" ? 40 : key === "portrait" ? 45 : 50;
                  return (
                    <button
                      key={key}
                      onClick={() => setActiveFormat(key)}
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        gap: 5,
                        background: "none",
                        border: "none",
                        cursor: "pointer",
                        padding: 0,
                      }}
                    >
                      <div
                        style={{
                          width: w,
                          height: h,
                          borderRadius: 3,
                          border: active ? `2px solid #f59e0b` : `2px solid rgba(255,255,255,0.15)`,
                          background: active ? "rgba(245,158,11,0.1)" : "rgba(255,255,255,0.04)",
                          transition: "all 0.2s",
                        }}
                      />
                      <div style={{ fontSize: 9, color: active ? "#f59e0b" : "#5a7099", fontFamily: "'Inter', sans-serif" }}>
                        {c.label.split("/")[0].trim()}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
