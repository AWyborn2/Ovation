export interface BattingPerformance {
  playerName: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
}

export interface BowlingPerformance {
  playerName: string;
  overs: number;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
}

export interface MatchData {
  clubSlug: string;
  matchTitle: string;
  matchDate: string;
  opponent: string;
  result: string; // e.g., "Won by 5 wickets", "Lost by 23 runs"
  totalScore: string; // e.g., "7/245"
  topBatters: BattingPerformance[];
  topBowlers: BowlingPerformance[];
}

export const sampleMatchData: MatchData = {
  clubSlug: "halls-head-cricket-club",
  matchTitle: "Round 5 - A Grade",
  matchDate: "5th June 2026",
  opponent: "Mandurah Cricket Club",
  result: "Won by 5 wickets",
  totalScore: "7/245",
  topBatters: [
    {
      playerName: "James Mitchell",
      runs: 87,
      balls: 64,
      fours: 9,
      sixes: 3,
      strikeRate: 135.94
    },
    {
      playerName: "Tom Anderson",
      runs: 62,
      balls: 48,
      fours: 7,
      sixes: 2,
      strikeRate: 129.17
    },
    {
      playerName: "Luke Stevens",
      runs: 45,
      balls: 38,
      fours: 5,
      sixes: 1,
      strikeRate: 118.42
    }
  ],
  topBowlers: [
    {
      playerName: "Ryan Thompson",
      overs: 8,
      maidens: 1,
      runs: 32,
      wickets: 4,
      economy: 4.0
    },
    {
      playerName: "Jake Williams",
      overs: 7,
      maidens: 0,
      runs: 38,
      wickets: 3,
      economy: 5.43
    },
    {
      playerName: "Matt Davis",
      overs: 6,
      maidens: 1,
      runs: 24,
      wickets: 2,
      economy: 4.0
    }
  ]
};
