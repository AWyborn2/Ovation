import { MatchData, InningsData } from "./types";
import { TeamLogo } from "./CricketLogo";

interface Props {
  data: MatchData;
  cardRef?: React.RefObject<HTMLDivElement>;
}

function InningsBlock({
  innings,
  data,
  compact,
}: {
  innings: InningsData;
  data: MatchData;
  compact?: boolean;
}) {
  const team = innings.teamKey === "club" ? data.club : data.opposition;
  const bowlingTeam = innings.teamKey === "club" ? data.opposition : data.club;

  const scoreStr = `${innings.wickets}/${innings.totalRuns}${innings.declared ? " DEC" : ""}`;
  const rowPad = compact ? "3px 10px" : "5px 12px";
  const nameFSize = compact ? 11 : 12;
  const statFSize = compact ? 12 : 14;
  const headerFSize = compact ? 13 : 15;
  const scoreFSize = compact ? 18 : 22;

  return (
    <div style={{ marginBottom: compact ? 6 : 8 }}>
      {/* Team header */}
      <div
        style={{
          background: team.primaryColor,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: compact ? "6px 10px" : "8px 14px",
          borderRadius: "3px 3px 0 0",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <TeamLogo
            logoUrl={team.logoUrl}
            teamName={team.name}
            size={compact ? 26 : 32}
            primaryColor={team.primaryColor}
          />
          <div>
            <div
              style={{
                fontFamily: "'Oswald', sans-serif",
                fontWeight: 700,
                color: team.textColor,
                fontSize: headerFSize,
                letterSpacing: "0.05em",
              }}
            >
              {innings.inningsNum === 2 ? "2ND INNINGS" : "1ST INNINGS"} — {team.name.toUpperCase()}
            </div>
            <div
              style={{
                fontFamily: "'Inter', sans-serif",
                color: team.secondaryColor,
                fontSize: compact ? 9 : 10,
                opacity: 0.9,
              }}
            >
              {innings.overs} OVERS
            </div>
          </div>
        </div>
        <div
          style={{
            fontFamily: "'Oswald', sans-serif",
            fontWeight: 700,
            color: team.textColor,
            fontSize: scoreFSize,
            letterSpacing: "0.02em",
          }}
        >
          {scoreStr}
        </div>
      </div>

      {/* Stats rows */}
      <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: "0 0 3px 3px" }}>
        {/* Column headers */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 60px 60px 1fr 60px 60px",
            padding: rowPad,
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textTransform: "uppercase", letterSpacing: "0.08em" }}>Batter</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textAlign: "right" }}>R</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textAlign: "right" }}>B</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textTransform: "uppercase", letterSpacing: "0.08em", paddingLeft: 8 }}>Bowler</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textAlign: "right" }}>W-R</div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: "#8fa5cc", textAlign: "right" }}>O</div>
        </div>
        {innings.topBatters.map((batter, i) => {
          const bowler = innings.topBowlers[i];
          return (
            <div
              key={batter.name}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 60px 60px 1fr 60px 60px",
                padding: rowPad,
                borderBottom: i < innings.topBatters.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
              }}
            >
              <div
                style={{
                  fontFamily: "'Roboto Condensed', sans-serif",
                  fontWeight: 700,
                  fontSize: nameFSize,
                  color: "#e8f0ff",
                }}
              >
                {batter.name}{batter.notOut ? "*" : ""}
              </div>
              <div
                style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 600,
                  fontSize: statFSize,
                  color: "#f59e0b",
                  textAlign: "right",
                }}
              >
                {batter.runs}
              </div>
              <div
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: nameFSize - 1,
                  color: "#8fa5cc",
                  textAlign: "right",
                }}
              >
                {batter.balls}
              </div>
              {bowler ? (
                <>
                  <div
                    style={{
                      fontFamily: "'Roboto Condensed', sans-serif",
                      fontWeight: 700,
                      fontSize: nameFSize,
                      color: "#e8f0ff",
                      paddingLeft: 8,
                    }}
                  >
                    {bowler.name}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Oswald', sans-serif",
                      fontWeight: 600,
                      fontSize: statFSize,
                      color: team.secondaryColor,
                      textAlign: "right",
                    }}
                  >
                    {bowler.wickets}/{bowler.runs}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: nameFSize - 1,
                      color: "#8fa5cc",
                      textAlign: "right",
                    }}
                  >
                    {bowler.overs}
                  </div>
                </>
              ) : (
                <div style={{ gridColumn: "span 3" }} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function SquareCard({ data, cardRef }: Props) {
  const isClubWinner = data.resultWinner === "club";
  const winnerColor =
    data.resultWinner === "club"
      ? data.club.primaryColor
      : data.resultWinner === "opposition"
      ? data.opposition.primaryColor
      : "#6b7280";

  const compact = data.innings.length > 2;

  return (
    <div
      ref={cardRef}
      id="card-square"
      style={{
        width: 1080,
        height: 1080,
        background: "linear-gradient(145deg, #0a0f1e 0%, #0d1528 50%, #091322 100%)",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', sans-serif",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Stadium atmosphere background */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(ellipse at 50% 0%, ${data.club.primaryColor}22 0%, transparent 55%), radial-gradient(ellipse at 50% 100%, ${data.opposition.primaryColor}15 0%, transparent 50%)`,
          pointerEvents: "none",
        }}
      />

      {/* Diagonal accent lines */}
      <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", opacity: 0.06 }}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              top: -200 + i * 300,
              left: -100,
              width: 3,
              height: 1500,
              background: "#ffffff",
              transform: "rotate(-25deg)",
            }}
          />
        ))}
      </div>

      {/* Header */}
      <div
        style={{
          padding: "28px 36px 18px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "2px solid rgba(255,255,255,0.08)",
          flexShrink: 0,
        }}
      >
        <div>
          <div
            style={{
              fontFamily: "'Oswald', sans-serif",
              fontWeight: 700,
              fontSize: 28,
              color: "#ffffff",
              letterSpacing: "0.04em",
            }}
          >
            MATCH SUMMARY
          </div>
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#8fa5cc",
              marginTop: 2,
            }}
          >
            {data.matchTitle} · {data.matchType}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc" }}>{data.date}</div>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#5a7099", marginTop: 2 }}>{data.venue}</div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <TeamLogo logoUrl={data.club.logoUrl} teamName={data.club.name} size={52} primaryColor={data.club.primaryColor} />
            <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 13, color: "#8fa5cc" }}>VS</div>
            <TeamLogo logoUrl={data.opposition.logoUrl} teamName={data.opposition.name} size={52} primaryColor={data.opposition.primaryColor} />
          </div>
        </div>
      </div>

      {/* Innings */}
      <div style={{ flex: 1, padding: "16px 36px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
        {data.innings.map((inn, i) => (
          <InningsBlock key={i} innings={inn} data={data} compact={compact} />
        ))}
      </div>

      {/* Result banner */}
      <div
        style={{
          background: `linear-gradient(90deg, ${winnerColor} 0%, ${winnerColor}cc 100%)`,
          padding: "16px 36px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          borderTop: "3px solid rgba(255,255,255,0.2)",
        }}
      >
        <div
          style={{
            fontFamily: "'Oswald', sans-serif",
            fontWeight: 700,
            fontSize: 24,
            color: "#ffffff",
            letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}
        >
          {data.result}
        </div>
      </div>

      {/* Club branding strip */}
      <div
        style={{
          background: "rgba(0,0,0,0.5)",
          padding: "8px 36px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 11, color: "#5a7099", letterSpacing: "0.1em" }}>
          {data.club.name.toUpperCase()} · OFFICIAL
        </div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#3d5070" }}>
          #CricketSocials
        </div>
      </div>
    </div>
  );
}
