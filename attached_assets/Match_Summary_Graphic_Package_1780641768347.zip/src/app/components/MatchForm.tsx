import { useState } from "react";
import { MatchData, InningsData, BatterStat, BowlerStat } from "./types";
import { ChevronDown, ChevronUp, Plus, Trash2, RefreshCw } from "lucide-react";
import { defaultMatchData } from "./types";

interface Props {
  data: MatchData;
  onChange: (data: MatchData) => void;
}

function ColorInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <label style={{ fontSize: 11, color: "#8fa5cc", letterSpacing: "0.05em", textTransform: "uppercase" }}>{label}</label>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{
            width: 32,
            height: 32,
            border: "1px solid rgba(255,255,255,0.15)",
            borderRadius: 4,
            background: "none",
            cursor: "pointer",
            padding: 2,
          }}
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{
            flex: 1,
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 4,
            padding: "5px 8px",
            color: "#e8f0ff",
            fontSize: 12,
            fontFamily: "'Inter', sans-serif",
          }}
        />
      </div>
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <label style={{ fontSize: 11, color: "#8fa5cc", letterSpacing: "0.05em", textTransform: "uppercase" }}>{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 4,
          padding: "7px 10px",
          color: "#e8f0ff",
          fontSize: 13,
          fontFamily: "'Inter', sans-serif",
          width: "100%",
        }}
      />
    </div>
  );
}

function InningsEditor({
  innings,
  index,
  data,
  onChange,
  onRemove,
}: {
  innings: InningsData;
  index: number;
  data: MatchData;
  onChange: (inn: InningsData) => void;
  onRemove: () => void;
}) {
  const [open, setOpen] = useState(index === 0);
  const team = innings.teamKey === "club" ? data.club : data.opposition;

  const updateBatter = (i: number, field: keyof BatterStat, val: string | number | boolean) => {
    const batters = [...innings.topBatters];
    batters[i] = { ...batters[i], [field]: val };
    onChange({ ...innings, topBatters: batters });
  };

  const updateBowler = (i: number, field: keyof BowlerStat, val: string | number) => {
    const bowlers = [...innings.topBowlers];
    bowlers[i] = { ...bowlers[i], [field]: val };
    onChange({ ...innings, topBowlers: bowlers });
  };

  const addBatter = () =>
    onChange({
      ...innings,
      topBatters: [...innings.topBatters, { name: "PLAYER", runs: 0, balls: 0 }],
    });

  const addBowler = () =>
    onChange({
      ...innings,
      topBowlers: [...innings.topBowlers, { name: "PLAYER", wickets: 0, runs: 0, overs: "0" }],
    });

  return (
    <div
      style={{
        border: `1px solid ${team.primaryColor}44`,
        borderRadius: 6,
        overflow: "hidden",
        marginBottom: 8,
      }}
    >
      {/* Header */}
      <div
        onClick={() => setOpen(!open)}
        style={{
          background: `${team.primaryColor}33`,
          padding: "10px 14px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer",
          userSelect: "none",
        }}
      >
        <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 13, color: "#e8f0ff", letterSpacing: "0.04em" }}>
          {innings.inningsNum === 2 ? "2ND" : "1ST"} INNINGS — {team.name.toUpperCase()}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            onClick={(e) => { e.stopPropagation(); onRemove(); }}
            style={{ background: "none", border: "none", cursor: "pointer", color: "#dc2626", padding: 2 }}
          >
            <Trash2 size={13} />
          </button>
          {open ? <ChevronUp size={14} color="#8fa5cc" /> : <ChevronDown size={14} color="#8fa5cc" />}
        </div>
      </div>

      {open && (
        <div style={{ padding: "12px 14px", background: "rgba(0,0,0,0.2)" }}>
          {/* Innings basics */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <label style={{ fontSize: 11, color: "#8fa5cc", textTransform: "uppercase" }}>Team</label>
              <select
                value={innings.teamKey}
                onChange={(e) => onChange({ ...innings, teamKey: e.target.value as "club" | "opposition" })}
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 4,
                  padding: "6px 8px",
                  color: "#e8f0ff",
                  fontSize: 12,
                }}
              >
                <option value="club">{data.club.shortName}</option>
                <option value="opposition">{data.opposition.shortName}</option>
              </select>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <label style={{ fontSize: 11, color: "#8fa5cc", textTransform: "uppercase" }}>Innings</label>
              <select
                value={innings.inningsNum}
                onChange={(e) => onChange({ ...innings, inningsNum: Number(e.target.value) as 1 | 2 })}
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 4,
                  padding: "6px 8px",
                  color: "#e8f0ff",
                  fontSize: 12,
                }}
              >
                <option value={1}>1st</option>
                <option value={2}>2nd</option>
              </select>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <label style={{ fontSize: 11, color: "#8fa5cc", textTransform: "uppercase" }}>Declared</label>
              <div style={{ display: "flex", alignItems: "center", height: 34 }}>
                <input
                  type="checkbox"
                  checked={!!innings.declared}
                  onChange={(e) => onChange({ ...innings, declared: e.target.checked })}
                  style={{ width: 16, height: 16, cursor: "pointer" }}
                />
              </div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 14 }}>
            <TextInput
              label="Runs"
              value={innings.totalRuns}
              onChange={(v) => onChange({ ...innings, totalRuns: v })}
              placeholder="284"
            />
            <TextInput
              label="Wickets"
              value={innings.wickets}
              onChange={(v) => onChange({ ...innings, wickets: v })}
              placeholder="8"
            />
            <TextInput
              label="Overs"
              value={innings.overs}
              onChange={(v) => onChange({ ...innings, overs: v })}
              placeholder="85.3"
            />
          </div>

          {/* Batters */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: "#f59e0b", letterSpacing: "0.08em", marginBottom: 6, textTransform: "uppercase" }}>
              Top Batters
            </div>
            {innings.topBatters.map((b, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 60px 60px 28px", gap: 6, marginBottom: 6, alignItems: "end" }}>
                <input
                  type="text"
                  value={b.name}
                  onChange={(e) => updateBatter(i, "name", e.target.value)}
                  placeholder="PLAYER NAME"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#e8f0ff", fontSize: 12 }}
                />
                <input
                  type="number"
                  value={b.runs}
                  onChange={(e) => updateBatter(i, "runs", Number(e.target.value))}
                  placeholder="R"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#f59e0b", fontSize: 12, textAlign: "center" }}
                />
                <input
                  type="number"
                  value={b.balls}
                  onChange={(e) => updateBatter(i, "balls", Number(e.target.value))}
                  placeholder="B"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#8fa5cc", fontSize: 12, textAlign: "center" }}
                />
                <button
                  onClick={() => onChange({ ...innings, topBatters: innings.topBatters.filter((_, j) => j !== i) })}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#dc2626", padding: 4 }}
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
            <button
              onClick={addBatter}
              style={{ display: "flex", alignItems: "center", gap: 4, background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 4, padding: "4px 10px", color: "#f59e0b", fontSize: 11, cursor: "pointer" }}
            >
              <Plus size={11} /> Add Batter
            </button>
          </div>

          {/* Bowlers */}
          <div>
            <div style={{ fontSize: 11, color: team.secondaryColor, letterSpacing: "0.08em", marginBottom: 6, textTransform: "uppercase" }}>
              Top Bowlers
            </div>
            {innings.topBowlers.map((b, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 45px 45px 50px 28px", gap: 6, marginBottom: 6, alignItems: "end" }}>
                <input
                  type="text"
                  value={b.name}
                  onChange={(e) => updateBowler(i, "name", e.target.value)}
                  placeholder="PLAYER NAME"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#e8f0ff", fontSize: 12 }}
                />
                <input
                  type="number"
                  value={b.wickets}
                  onChange={(e) => updateBowler(i, "wickets", Number(e.target.value))}
                  placeholder="W"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: team.secondaryColor, fontSize: 12, textAlign: "center" }}
                />
                <input
                  type="number"
                  value={b.runs}
                  onChange={(e) => updateBowler(i, "runs", Number(e.target.value))}
                  placeholder="R"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#8fa5cc", fontSize: 12, textAlign: "center" }}
                />
                <input
                  type="text"
                  value={b.overs}
                  onChange={(e) => updateBowler(i, "overs", e.target.value)}
                  placeholder="Ov"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "5px 8px", color: "#8fa5cc", fontSize: 12, textAlign: "center" }}
                />
                <button
                  onClick={() => onChange({ ...innings, topBowlers: innings.topBowlers.filter((_, j) => j !== i) })}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#dc2626", padding: 4 }}
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
            <button
              onClick={addBowler}
              style={{ display: "flex", alignItems: "center", gap: 4, background: `${team.primaryColor}20`, border: `1px solid ${team.primaryColor}44`, borderRadius: 4, padding: "4px 10px", color: team.secondaryColor, fontSize: 11, cursor: "pointer" }}
            >
              <Plus size={11} /> Add Bowler
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 12, color: "#f59e0b", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10, borderBottom: "1px solid rgba(245,158,11,0.2)", paddingBottom: 6 }}>
        {title}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {children}
      </div>
    </div>
  );
}

export function MatchForm({ data, onChange }: Props) {
  const updateClub = (field: string, val: string) =>
    onChange({ ...data, club: { ...data.club, [field]: val } });

  const updateOpposition = (field: string, val: string) =>
    onChange({ ...data, opposition: { ...data.opposition, [field]: val } });

  const updateInnings = (index: number, inn: InningsData) => {
    const innings = [...data.innings];
    innings[index] = inn;
    onChange({ ...data, innings });
  };

  const addInnings = () => {
    const newInn: InningsData = {
      teamKey: "club",
      inningsNum: 1,
      totalRuns: "0",
      wickets: "0",
      overs: "0",
      topBatters: [{ name: "PLAYER A", runs: 0, balls: 0 }],
      topBowlers: [{ name: "PLAYER B", wickets: 0, runs: 0, overs: "0" }],
    };
    onChange({ ...data, innings: [...data.innings, newInn] });
  };

  return (
    <div
      style={{
        height: "100%",
        overflowY: "auto",
        padding: "20px 18px",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Reset */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
        <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 16, color: "#ffffff", letterSpacing: "0.04em" }}>
          MATCH DATA
        </div>
        <button
          onClick={() => onChange(defaultMatchData)}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 5,
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 4,
            padding: "5px 10px",
            color: "#8fa5cc",
            fontSize: 11,
            cursor: "pointer",
          }}
        >
          <RefreshCw size={11} /> Reset
        </button>
      </div>

      <Section title="Match Info">
        <TextInput label="Match Title" value={data.matchTitle} onChange={(v) => onChange({ ...data, matchTitle: v })} placeholder="Grade 1 — Round 14" />
        <TextInput label="Match Type" value={data.matchType} onChange={(v) => onChange({ ...data, matchType: v })} placeholder="2-Day Club Cricket" />
        <TextInput label="Date" value={data.date} onChange={(v) => onChange({ ...data, date: v })} placeholder="June 7, 2026" />
        <TextInput label="Venue" value={data.venue} onChange={(v) => onChange({ ...data, venue: v })} placeholder="Home Oval" />
        <TextInput label="Result" value={data.result} onChange={(v) => onChange({ ...data, result: v })} placeholder="Team won by X runs" />
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <label style={{ fontSize: 11, color: "#8fa5cc", textTransform: "uppercase" }}>Result Winner</label>
          <select
            value={data.resultWinner}
            onChange={(e) => onChange({ ...data, resultWinner: e.target.value as "club" | "opposition" | "draw" })}
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 4, padding: "6px 8px", color: "#e8f0ff", fontSize: 12 }}
          >
            <option value="club">{data.club.name} (Club)</option>
            <option value="opposition">{data.opposition.name}</option>
            <option value="draw">Draw / Tie</option>
          </select>
        </div>
      </Section>

      <Section title="Your Club">
        <TextInput label="Club Name" value={data.club.name} onChange={(v) => updateClub("name", v)} />
        <TextInput label="Short Name" value={data.club.shortName} onChange={(v) => updateClub("shortName", v)} placeholder="RCC" />
        <TextInput label="Logo URL" value={data.club.logoUrl} onChange={(v) => updateClub("logoUrl", v)} placeholder="https://..." />
        <ColorInput label="Primary Color" value={data.club.primaryColor} onChange={(v) => updateClub("primaryColor", v)} />
        <ColorInput label="Secondary Color" value={data.club.secondaryColor} onChange={(v) => updateClub("secondaryColor", v)} />
      </Section>

      <Section title="Opposition">
        <TextInput label="Club Name" value={data.opposition.name} onChange={(v) => updateOpposition("name", v)} />
        <TextInput label="Short Name" value={data.opposition.shortName} onChange={(v) => updateOpposition("shortName", v)} placeholder="CHCC" />
        <TextInput label="Logo URL" value={data.opposition.logoUrl} onChange={(v) => updateOpposition("logoUrl", v)} placeholder="https://..." />
        <ColorInput label="Primary Color" value={data.opposition.primaryColor} onChange={(v) => updateOpposition("primaryColor", v)} />
        <ColorInput label="Secondary Color" value={data.opposition.secondaryColor} onChange={(v) => updateOpposition("secondaryColor", v)} />
      </Section>

      <Section title="Innings">
        {data.innings.map((inn, i) => (
          <InningsEditor
            key={i}
            innings={inn}
            index={i}
            data={data}
            onChange={(updated) => updateInnings(i, updated)}
            onRemove={() => onChange({ ...data, innings: data.innings.filter((_, j) => j !== i) })}
          />
        ))}
        <button
          onClick={addInnings}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            background: "rgba(30,64,175,0.2)",
            border: "1px dashed rgba(30,64,175,0.5)",
            borderRadius: 6,
            padding: "10px",
            color: "#93c5fd",
            fontSize: 12,
            cursor: "pointer",
            width: "100%",
            fontFamily: "'Inter', sans-serif",
          }}
        >
          <Plus size={13} /> Add Innings
        </button>
      </Section>
    </div>
  );
}
