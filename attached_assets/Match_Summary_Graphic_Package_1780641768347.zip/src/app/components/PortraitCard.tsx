import { MatchData, InningsData } from "./types";
import { TeamLogo } from "./CricketLogo";

interface Props {
  data: MatchData;
  cardRef?: React.RefObject<HTMLDivElement>;
}

function InningsSection({ innings, data }: { innings: InningsData; data: MatchData }) {
  const team = innings.teamKey === "club" ? data.club : data.opposition;
  const scoreStr = `${innings.wickets}/${innings.totalRuns}${innings.declared ? " DEC" : ""}`;

  return (
    <div style={{ marginBottom: 14 }}>
      {/* Header */}
      <div
        style={{
          background: `linear-gradient(90deg, ${team.primaryColor} 0%, ${team.primaryColor}99 100%)`,
          borderRadius: "4px 4px 0 0",
          padding: "10px 16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <TeamLogo logoUrl={team.logoUrl} teamName={team.name} size={36} primaryColor={team.primaryColor} />
          <div>
            <div
              style={{
                fontFamily: "'Oswald', sans-serif",
                fontWeight: 700,
                fontSize: 16,
                color: team.textColor,
                letterSpacing: "0.05em",
              }}
            >
              {innings.inningsNum === 2 ? "2ND INNINGS" : "1ST INNINGS"} — {team.shortName}
            </div>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: team.secondaryColor }}>
              {innings.overs} OVERS
            </div>
          </div>
        </div>
        <div
          style={{
            fontFamily: "'Oswald', sans-serif",
            fontWeight: 700,
            fontSize: 28,
            color: team.textColor,
          }}
        >
          {scoreStr}
        </div>
      </div>

      {/* Stats */}
      <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: "0 0 4px 4px" }}>
        {/* Header row */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 50px 50px 1fr 55px 45px",
            padding: "5px 14px",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          {["BATTER", "R", "B", "BOWLER", "W/R", "O"].map((h, i) => (
            <div
              key={i}
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 9,
                color: "#8fa5cc",
                textAlign: i > 0 && i < 3 ? "right" : i > 3 ? "right" : "left",
                letterSpacing: "0.06em",
                paddingLeft: i === 3 ? 8 : 0,
              }}
            >
              {h}
            </div>
          ))}
        </div>

        {innings.topBatters.map((batter, i) => {
          const bowler = innings.topBowlers[i];
          return (
            <div
              key={batter.name}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 50px 50px 1fr 55px 45px",
                padding: "7px 14px",
                borderBottom: i < innings.topBatters.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                alignItems: "center",
              }}
            >
              <div style={{ fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#e8f0ff" }}>
                {batter.name}{batter.notOut ? "*" : ""}
              </div>
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 16, color: "#f59e0b", textAlign: "right" }}>
                {batter.runs}
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc", textAlign: "right" }}>
                {batter.balls}
              </div>
              {bowler ? (
                <>
                  <div style={{ fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#e8f0ff", paddingLeft: 8 }}>
                    {bowler.name}
                  </div>
                  <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 16, color: team.secondaryColor, textAlign: "right" }}>
                    {bowler.wickets}/{bowler.runs}
                  </div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc", textAlign: "right" }}>
                    {bowler.overs}
                  </div>
                </>
              ) : <div style={{ gridColumn: "span 3" }} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function PortraitCard({ data, cardRef }: Props) {
  const winnerColor =
    data.resultWinner === "club"
      ? data.club.primaryColor
      : data.resultWinner === "opposition"
      ? data.opposition.primaryColor
      : "#4b5563";

  return (
    <div
      ref={cardRef}
      id="card-portrait"
      style={{
        width: 1080,
        height: 1350,
        background: "linear-gradient(160deg, #0a0f1e 0%, #0d1528 60%, #091322 100%)",
        position: "relative",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Background glow */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(ellipse at 30% 10%, ${data.club.primaryColor}25 0%, transparent 45%), radial-gradient(ellipse at 70% 90%, ${data.opposition.primaryColor}20 0%, transparent 45%)`,
          pointerEvents: "none",
        }}
      />

      {/* Hero header */}
      <div
        style={{
          padding: "42px 48px 28px",
          flexShrink: 0,
          borderBottom: "2px solid rgba(255,255,255,0.07)",
        }}
      >
        {/* Top row: club branding */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <TeamLogo logoUrl={data.club.logoUrl} teamName={data.club.name} size={64} primaryColor={data.club.primaryColor} />
            <div>
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 22, color: "#ffffff", letterSpacing: "0.04em" }}>
                {data.club.name.toUpperCase()}
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc", marginTop: 2 }}>
                {data.matchType}
              </div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#c8d6ef" }}>{data.date}</div>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#5a7099", marginTop: 3 }}>{data.venue}</div>
          </div>
        </div>

        {/* Match title */}
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              fontFamily: "'Oswald', sans-serif",
              fontWeight: 700,
              fontSize: 40,
              color: "#ffffff",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            MATCH SUMMARY
          </div>
          <div
            style={{
              fontFamily: "'Roboto Condensed', sans-serif",
              fontSize: 18,
              color: "#8fa5cc",
              marginTop: 4,
              letterSpacing: "0.08em",
            }}
          >
            {data.club.name} vs {data.opposition.name}
          </div>
          <div
            style={{
              width: 60,
              height: 3,
              background: `linear-gradient(90deg, ${data.club.primaryColor}, ${data.opposition.primaryColor})`,
              borderRadius: 2,
              margin: "12px auto 0",
            }}
          />
        </div>
      </div>

      {/* Innings */}
      <div style={{ flex: 1, padding: "24px 48px", overflow: "hidden" }}>
        {data.innings.map((inn, i) => (
          <InningsSection key={i} innings={inn} data={data} />
        ))}
      </div>

      {/* Result banner */}
      <div
        style={{
          background: `linear-gradient(90deg, ${winnerColor}ee 0%, ${winnerColor}bb 50%, ${winnerColor}dd 100%)`,
          padding: "22px 48px",
          textAlign: "center",
          flexShrink: 0,
          borderTop: "3px solid rgba(255,255,255,0.2)",
        }}
      >
        <div
          style={{
            fontFamily: "'Oswald', sans-serif",
            fontWeight: 700,
            fontSize: 28,
            color: "#ffffff",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          {data.result}
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          background: "rgba(0,0,0,0.6)",
          padding: "10px 48px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 12, color: "#5a7099", letterSpacing: "0.1em" }}>
          {data.club.name.toUpperCase()} · OFFICIAL
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: data.club.primaryColor }} />
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#3d5070" }}>#CricketSocials</div>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: data.opposition.primaryColor }} />
        </div>
      </div>
    </div>
  );
}
