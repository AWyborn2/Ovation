import { motion, useAnimation } from "motion/react";
import { useEffect, useState } from "react";
import { MatchData, InningsData } from "./types";
import { TeamLogo } from "./CricketLogo";

interface Props {
  data: MatchData;
  cardRef?: React.RefObject<HTMLDivElement>;
  isPlaying?: boolean;
}

function AnimatedInningsBlock({
  innings,
  data,
  delay,
}: {
  innings: InningsData;
  data: MatchData;
  delay: number;
}) {
  const team = innings.teamKey === "club" ? data.club : data.opposition;
  const scoreStr = `${innings.wickets}/${innings.totalRuns}${innings.declared ? " DEC" : ""}`;

  return (
    <motion.div
      initial={{ x: -80, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      style={{ marginBottom: 16 }}
    >
      {/* Team header */}
      <div
        style={{
          background: `linear-gradient(90deg, ${team.primaryColor} 0%, ${team.primaryColor}bb 100%)`,
          borderRadius: "4px 4px 0 0",
          padding: "12px 18px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderLeft: `5px solid rgba(255,255,255,0.4)`,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <TeamLogo logoUrl={team.logoUrl} teamName={team.name} size={40} primaryColor={team.primaryColor} />
          <div>
            <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 15, color: team.textColor, letterSpacing: "0.05em" }}>
              {innings.inningsNum === 2 ? "2ND INNINGS" : "1ST INNINGS"}
            </div>
            <div style={{ fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: team.secondaryColor }}>
              {team.name.toUpperCase()} · {innings.overs} OVS
            </div>
          </div>
        </div>
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: delay + 0.3, ease: "backOut" }}
          style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 32, color: team.textColor }}
        >
          {scoreStr}
        </motion.div>
      </div>

      {/* Stats */}
      <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: "0 0 4px 4px" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 55px 50px 1fr 55px 45px",
            padding: "5px 16px",
            borderBottom: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          {["BATTER", "R", "B", "BOWLER", "W/R", "O"].map((h, i) => (
            <div
              key={i}
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 9,
                color: "#8fa5cc",
                textAlign: i > 0 && i < 3 ? "right" : i > 3 ? "right" : "left",
                paddingLeft: i === 3 ? 8 : 0,
                letterSpacing: "0.06em",
              }}
            >
              {h}
            </div>
          ))}
        </div>
        {innings.topBatters.map((batter, i) => {
          const bowler = innings.topBowlers[i];
          return (
            <motion.div
              key={batter.name}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay + 0.4 + i * 0.12 }}
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 55px 50px 1fr 55px 45px",
                padding: "8px 16px",
                borderBottom: i < innings.topBatters.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                alignItems: "center",
              }}
            >
              <div style={{ fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#e8f0ff" }}>
                {batter.name}{batter.notOut ? "*" : ""}
              </div>
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 18, color: "#f59e0b", textAlign: "right" }}>
                {batter.runs}
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc", textAlign: "right" }}>
                {batter.balls}
              </div>
              {bowler ? (
                <>
                  <div style={{ fontFamily: "'Roboto Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#e8f0ff", paddingLeft: 8 }}>
                    {bowler.name}
                  </div>
                  <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 18, color: team.secondaryColor, textAlign: "right" }}>
                    {bowler.wickets}/{bowler.runs}
                  </div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#8fa5cc", textAlign: "right" }}>
                    {bowler.overs}
                  </div>
                </>
              ) : <div style={{ gridColumn: "span 3" }} />}
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}

export function StoriesCard({ data, cardRef, isPlaying = true }: Props) {
  const winnerColor =
    data.resultWinner === "club"
      ? data.club.primaryColor
      : data.resultWinner === "opposition"
      ? data.opposition.primaryColor
      : "#4b5563";

  const [key, setKey] = useState(0);

  useEffect(() => {
    if (isPlaying) setKey((k) => k + 1);
  }, [isPlaying]);

  const delays = data.innings.reduce<number[]>((acc, inn, i) => {
    const prev = acc[i - 1] ?? 0;
    const rowCount = Math.max(inn.topBatters.length, inn.topBowlers.length);
    return [...acc, prev + 0.9 + rowCount * 0.15];
  }, []);
  const lastDelay = delays[delays.length - 1] ?? 1;

  return (
    <div
      ref={cardRef}
      id="card-stories"
      style={{
        width: 1080,
        height: 1920,
        background: "linear-gradient(170deg, #080d1c 0%, #0d1528 45%, #091322 100%)",
        position: "relative",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Animated background glow */}
      <motion.div
        key={`bg-${key}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(ellipse at 20% 15%, ${data.club.primaryColor}30 0%, transparent 50%), radial-gradient(ellipse at 80% 85%, ${data.opposition.primaryColor}25 0%, transparent 50%), radial-gradient(ellipse at 50% 50%, #1e40af18 0%, transparent 60%)`,
          pointerEvents: "none",
        }}
      />

      {/* Animated diagonal stripes */}
      <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", opacity: 0.04 }}>
        {[0, 1, 2, 3, 4].map((i) => (
          <motion.div
            key={`stripe-${i}`}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1, duration: 1 }}
            style={{
              position: "absolute",
              top: -300 + i * 400,
              left: -100,
              width: 4,
              height: 2500,
              background: "#ffffff",
              transform: "rotate(-20deg)",
            }}
          />
        ))}
      </div>

      {/* Hero section */}
      <div style={{ padding: "60px 52px 32px", flexShrink: 0 }}>
        {/* Club logo + name */}
        <motion.div
          key={`header-${key}`}
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <TeamLogo logoUrl={data.club.logoUrl} teamName={data.club.name} size={72} primaryColor={data.club.primaryColor} />
            <div>
              <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 24, color: "#ffffff", letterSpacing: "0.04em" }}>
                {data.club.name.toUpperCase()}
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#8fa5cc", marginTop: 3 }}>
                {data.matchType}
              </div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "#c8d6ef" }}>{data.date}</div>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#5a7099", marginTop: 3 }}>{data.venue}</div>
          </div>
        </motion.div>

        {/* MATCH SUMMARY title */}
        <motion.div
          key={`title-${key}`}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2, ease: "backOut" }}
          style={{ textAlign: "center", marginBottom: 16 }}
        >
          <div
            style={{
              fontFamily: "'Oswald', sans-serif",
              fontWeight: 700,
              fontSize: 58,
              color: "#ffffff",
              letterSpacing: "0.06em",
              lineHeight: 1,
              textTransform: "uppercase",
            }}
          >
            MATCH
          </div>
          <div
            style={{
              fontFamily: "'Oswald', sans-serif",
              fontWeight: 700,
              fontSize: 58,
              color: "#f59e0b",
              letterSpacing: "0.06em",
              lineHeight: 1,
              textTransform: "uppercase",
            }}
          >
            SUMMARY
          </div>
          <div
            style={{
              fontFamily: "'Roboto Condensed', sans-serif",
              fontSize: 18,
              color: "#8fa5cc",
              marginTop: 10,
              letterSpacing: "0.1em",
            }}
          >
            {data.club.name} vs {data.opposition.name}
          </div>
        </motion.div>

        {/* Team vs strip */}
        <motion.div
          key={`vs-${key}`}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.5, delay: 0.5, ease: "easeOut" }}
          style={{
            height: 4,
            background: `linear-gradient(90deg, ${data.club.primaryColor} 0%, ${data.club.primaryColor} 48%, rgba(255,255,255,0.3) 48%, rgba(255,255,255,0.3) 52%, ${data.opposition.primaryColor} 52%, ${data.opposition.primaryColor} 100%)`,
            borderRadius: 2,
            marginBottom: 28,
          }}
        />

        {/* Score summary (club vs opposition) */}
        <motion.div
          key={`scores-${key}`}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          style={{ display: "flex", alignItems: "stretch", gap: 12, marginBottom: 8 }}
        >
          {/* Club innings totals */}
          <div
            style={{
              flex: 1,
              background: `${data.club.primaryColor}22`,
              border: `1px solid ${data.club.primaryColor}44`,
              borderRadius: 6,
              padding: "12px 16px",
            }}
          >
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: data.club.secondaryColor, marginBottom: 6, letterSpacing: "0.06em" }}>
              {data.club.name.toUpperCase()}
            </div>
            {data.innings
              .filter((i) => i.teamKey === "club")
              .map((inn, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#8fa5cc" }}>
                    {inn.inningsNum === 2 ? "2nd" : "1st"}
                  </div>
                  <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 18, color: "#ffffff" }}>
                    {inn.wickets}/{inn.totalRuns}{inn.declared ? " DEC" : ""}
                  </div>
                </div>
              ))}
          </div>

          {/* VS */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", width: 36 }}>
            <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 16, color: "#5a7099" }}>VS</div>
          </div>

          {/* Opposition innings totals */}
          <div
            style={{
              flex: 1,
              background: `${data.opposition.primaryColor}22`,
              border: `1px solid ${data.opposition.primaryColor}44`,
              borderRadius: 6,
              padding: "12px 16px",
            }}
          >
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: data.opposition.secondaryColor, marginBottom: 6, letterSpacing: "0.06em" }}>
              {data.opposition.name.toUpperCase()}
            </div>
            {data.innings
              .filter((i) => i.teamKey === "opposition")
              .map((inn, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#8fa5cc" }}>
                    {inn.inningsNum === 2 ? "2nd" : "1st"}
                  </div>
                  <div style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 18, color: "#ffffff" }}>
                    {inn.wickets}/{inn.totalRuns}{inn.declared ? " DEC" : ""}
                  </div>
                </div>
              ))}
          </div>
        </motion.div>
      </div>

      {/* Innings detail */}
      <div style={{ flex: 1, padding: "0 52px", overflow: "hidden" }} key={key}>
        {data.innings.map((inn, i) => (
          <AnimatedInningsBlock key={`${key}-${i}`} innings={inn} data={data} delay={0.8 + i * 0.9} />
        ))}
      </div>

      {/* Result banner */}
      <motion.div
        key={`result-${key}`}
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: lastDelay + 0.3, ease: [0.22, 1, 0.36, 1] }}
        style={{
          background: `linear-gradient(90deg, ${winnerColor} 0%, ${winnerColor}cc 50%, ${winnerColor}ee 100%)`,
          padding: "28px 52px",
          textAlign: "center",
          flexShrink: 0,
          borderTop: "4px solid rgba(255,255,255,0.25)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Shimmer animation */}
        <motion.div
          key={`shimmer-${key}`}
          initial={{ x: -300, opacity: 0 }}
          animate={{ x: 1200, opacity: [0, 0.4, 0] }}
          transition={{ duration: 1.2, delay: lastDelay + 0.9, ease: "easeInOut" }}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: 200,
            height: "100%",
            background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)",
            transform: "skewX(-20deg)",
          }}
        />
        <div
          style={{
            fontFamily: "'Oswald', sans-serif",
            fontWeight: 700,
            fontSize: 32,
            color: "#ffffff",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
          }}
        >
          {data.result}
        </div>
      </motion.div>

      {/* Footer */}
      <div
        style={{
          background: "rgba(0,0,0,0.7)",
          padding: "14px 52px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 13, color: "#5a7099", letterSpacing: "0.1em" }}>
          {data.club.name.toUpperCase()} · OFFICIAL
        </div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#3d5070" }}>
          #CricketSocials
        </div>
      </div>
    </div>
  );
}
