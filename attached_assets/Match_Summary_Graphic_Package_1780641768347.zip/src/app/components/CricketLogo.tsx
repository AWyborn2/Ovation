interface CricketLogoProps {
  size?: number;
  color?: string;
}

export function CricketLogo({ size = 60, color = "#ffffff" }: CricketLogoProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="30" cy="30" r="28" stroke={color} strokeWidth="2" fill="none" opacity="0.3" />
      <circle cx="30" cy="30" r="22" stroke={color} strokeWidth="1.5" fill="none" opacity="0.2" />
      {/* Cricket ball seam lines */}
      <path d="M 10 30 Q 20 18 30 30 Q 40 42 50 30" stroke={color} strokeWidth="2" fill="none" />
      <path d="M 10 30 Q 20 42 30 30 Q 40 18 50 30" stroke={color} strokeWidth="2" fill="none" />
      {/* Bat */}
      <rect x="26" y="6" width="8" height="24" rx="2" fill={color} opacity="0.9" />
      <rect x="25" y="30" width="10" height="6" rx="1" fill={color} opacity="0.7" />
      <rect x="27" y="36" width="6" height="14" rx="1" fill={color} opacity="0.5" />
    </svg>
  );
}

interface TeamLogoProps {
  logoUrl: string;
  teamName: string;
  size?: number;
  primaryColor?: string;
}

export function TeamLogo({ logoUrl, teamName, size = 60, primaryColor = "#1e40af" }: TeamLogoProps) {
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={teamName}
        style={{ width: size, height: size, objectFit: "contain" }}
      />
    );
  }

  const initials = teamName
    .split(" ")
    .filter((w) => w.length > 1)
    .slice(0, 2)
    .map((w) => w[0])
    .join("");

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: `radial-gradient(circle at 35% 35%, ${primaryColor}dd, ${primaryColor}88)`,
        border: `2px solid rgba(255,255,255,0.4)`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "'Oswald', sans-serif",
        fontWeight: 700,
        color: "#ffffff",
        fontSize: size * 0.32,
        letterSpacing: "0.05em",
        boxShadow: `0 0 ${size * 0.3}px ${primaryColor}55`,
      }}
    >
      {initials}
    </div>
  );
}
