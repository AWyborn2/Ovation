export interface TeamConfig {
  name: string;
  shortName: string;
  primaryColor: string;
  secondaryColor: string;
  textColor: string;
  logoUrl: string;
}

export interface BatterStat {
  name: string;
  runs: number;
  balls: number;
  notOut?: boolean;
}

export interface BowlerStat {
  name: string;
  wickets: number;
  runs: number;
  overs: string;
}

export interface InningsData {
  teamKey: "club" | "opposition";
  inningsNum: 1 | 2;
  totalRuns: string;
  wickets: string;
  overs: string;
  declared?: boolean;
  topBatters: BatterStat[];
  topBowlers: BowlerStat[];
}

export interface MatchData {
  matchTitle: string;
  matchType: string;
  date: string;
  venue: string;
  result: string;
  resultWinner: "club" | "opposition" | "draw";
  club: TeamConfig;
  opposition: TeamConfig;
  innings: InningsData[];
}

export const defaultMatchData: MatchData = {
  matchTitle: "Grade 1 — Round 14",
  matchType: "2-Day Club Cricket",
  date: "June 7, 2026",
  venue: "Riverside Oval, Home",
  result: "Riverside CC won by 47 runs",
  resultWinner: "club",
  club: {
    name: "Riverside CC",
    shortName: "RCC",
    primaryColor: "#1e40af",
    secondaryColor: "#93c5fd",
    textColor: "#ffffff",
    logoUrl: "",
  },
  opposition: {
    name: "City Hawks CC",
    shortName: "CHCC",
    primaryColor: "#15803d",
    secondaryColor: "#86efac",
    textColor: "#ffffff",
    logoUrl: "",
  },
  innings: [
    {
      teamKey: "club",
      inningsNum: 1,
      totalRuns: "284",
      wickets: "8",
      overs: "85.3",
      declared: true,
      topBatters: [
        { name: "J. HARRISON", runs: 112, balls: 187, notOut: false },
        { name: "M. CHEN", runs: 74, balls: 103, notOut: false },
      ],
      topBowlers: [
        { name: "R. THOMPSON", wickets: 4, runs: 52, overs: "18.2" },
        { name: "S. PATEL", wickets: 3, runs: 61, overs: "21" },
      ],
    },
    {
      teamKey: "opposition",
      inningsNum: 1,
      totalRuns: "198",
      wickets: "10",
      overs: "62.1",
      topBatters: [
        { name: "D. WALKER", runs: 68, balls: 94, notOut: false },
        { name: "B. MILLER", runs: 41, balls: 67, notOut: false },
      ],
      topBowlers: [
        { name: "A. BROOKS", wickets: 4, runs: 38, overs: "14" },
        { name: "T. NGUYEN", wickets: 3, runs: 47, overs: "16.4" },
      ],
    },
    {
      teamKey: "club",
      inningsNum: 2,
      totalRuns: "156",
      wickets: "4",
      overs: "41.0",
      declared: true,
      topBatters: [
        { name: "J. HARRISON", runs: 58, balls: 79, notOut: true },
        { name: "K. SANTOS", runs: 44, balls: 61, notOut: false },
      ],
      topBowlers: [
        { name: "R. THOMPSON", wickets: 3, runs: 44, overs: "13.2" },
        { name: "L. FORD", wickets: 2, runs: 39, overs: "12" },
      ],
    },
    {
      teamKey: "opposition",
      inningsNum: 2,
      totalRuns: "195",
      wickets: "10",
      overs: "58.4",
      topBatters: [
        { name: "D. WALKER", runs: 71, balls: 118, notOut: false },
        { name: "C. JAMES", runs: 39, balls: 55, notOut: false },
      ],
      topBowlers: [
        { name: "A. BROOKS", wickets: 5, runs: 49, overs: "17" },
        { name: "S. PATEL", wickets: 3, runs: 58, overs: "19.2" },
      ],
    },
  ],
};
