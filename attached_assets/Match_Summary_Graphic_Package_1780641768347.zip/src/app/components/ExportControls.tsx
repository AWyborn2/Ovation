import { useState } from 'react';
import { Download, Image as ImageIcon, Video } from 'lucide-react';
import { ExportFormat, formatDimensions, exportAsImage } from '../utils/exportUtils';

interface ExportControlsProps {
  graphicRef: React.RefObject<HTMLDivElement>;
  matchTitle: string;
  onExportVideo: () => void;
  isExportingVideo: boolean;
}

export function ExportControls({ 
  graphicRef, 
  matchTitle, 
  onExportVideo,
  isExportingVideo 
}: ExportControlsProps) {
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('square');
  const [isExporting, setIsExporting] = useState(false);

  const handleExportImage = async () => {
    if (!graphicRef.current) return;

    setIsExporting(true);
    try {
      const filename = `${matchTitle.replace(/\s+/g, '-').toLowerCase()}-summary`;
      await exportAsImage(graphicRef.current, selectedFormat, filename);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Failed to export image. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <h3 className="font-bold mb-4">Export Options</h3>
      
      {/* Format Selection */}
      <div className="mb-6">
        <label className="block mb-2 opacity-70">Select Format</label>
        <div className="grid grid-cols-1 gap-2">
          {(Object.keys(formatDimensions) as ExportFormat[]).map((format) => (
            <button
              key={format}
              onClick={() => setSelectedFormat(format)}
              className={`p-4 rounded-xl text-left transition-all ${
                selectedFormat === format
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              <div className="font-bold">{formatDimensions[format].label}</div>
              <div className="text-sm opacity-75 mt-1">
                {formatDimensions[format].width} × {formatDimensions[format].height}px
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Export Buttons */}
      <div className="space-y-3">
        <button
          onClick={handleExportImage}
          disabled={isExporting}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 rounded-xl font-bold hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-lg"
        >
          {isExporting ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <ImageIcon size={20} />
              Export as Image (PNG)
            </>
          )}
        </button>

        <button
          onClick={onExportVideo}
          disabled={isExportingVideo}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white px-6 py-4 rounded-xl font-bold hover:from-purple-700 hover:to-purple-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-lg"
        >
          {isExportingVideo ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Recording...
            </>
          ) : (
            <>
              <Video size={20} />
              Export as Video (MP4)
            </>
          )}
        </button>
      </div>

      <div className="mt-4 p-4 bg-blue-50 rounded-xl">
        <p className="text-sm opacity-75">
          <strong>Tip:</strong> Video exports capture the animation for social media stories. 
          The video will be approximately 5 seconds long.
        </p>
      </div>
    </div>
  );
}
