import { motion } from 'motion/react';
import { Club } from '../utils/clubData';
import { MatchData } from '../types/matchTypes';
import { ExportFormat, formatDimensions } from '../utils/exportUtils';

interface MatchGraphicProps {
  matchData: MatchData;
  club: Club;
  format: ExportFormat;
  animated?: boolean;
}

export function MatchGraphic({ matchData, club, format, animated = false }: MatchGraphicProps) {
  const dimensions = formatDimensions[format];
  const isStory = format === 'story';
  const isSquare = format === 'square';

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  const logoVariants = {
    hidden: { scale: 0, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: { type: 'spring', stiffness: 200, damping: 15 }
    }
  };

  const Container = animated ? motion.div : 'div';
  const Item = animated ? motion.div : 'div';

  return (
    <Container
      className="relative overflow-hidden"
      style={{
        width: `${dimensions.width}px`,
        height: `${dimensions.height}px`,
        background: `linear-gradient(135deg, ${club.primary} 0%, ${club.tertiary} 100%)`,
        color: club.secondary
      }}
      variants={animated ? containerVariants : undefined}
      initial={animated ? 'hidden' : undefined}
      animate={animated ? 'visible' : undefined}
    >
      {/* Background pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 35px,
            ${club.secondary} 35px,
            ${club.secondary} 70px
          )`
        }}
      />

      {/* Content wrapper */}
      <div className="relative z-10 flex flex-col h-full p-12">
        {/* Header */}
        <Item
          className="flex items-center justify-between mb-8"
          variants={animated ? itemVariants : undefined}
        >
          <div className="flex items-center gap-4">
            <motion.img
              src={club.logo}
              alt={club.name}
              className="object-contain"
              style={{
                width: isStory ? '120px' : '100px',
                height: isStory ? '120px' : '100px'
              }}
              variants={animated ? logoVariants : undefined}
              crossOrigin="anonymous"
            />
            <div>
              <h1 
                className="font-bold leading-tight"
                style={{
                  fontSize: isStory ? '42px' : isSquare ? '32px' : '36px',
                  color: club.secondary
                }}
              >
                {club.name}
              </h1>
              <p 
                className="opacity-90 mt-1"
                style={{
                  fontSize: isStory ? '24px' : '20px',
                  color: club.secondary
                }}
              >
                Match Summary
              </p>
            </div>
          </div>
        </Item>

        {/* Match Info */}
        <Item
          className="mb-8"
          variants={animated ? itemVariants : undefined}
        >
          <div 
            className="rounded-2xl p-6"
            style={{
              backgroundColor: `${club.secondary}22`,
              backdropFilter: 'blur(10px)'
            }}
          >
            <h2 
              className="font-bold mb-2"
              style={{
                fontSize: isStory ? '32px' : '28px',
                color: club.secondary
              }}
            >
              {matchData.matchTitle}
            </h2>
            <p 
              className="opacity-90 mb-3"
              style={{
                fontSize: isStory ? '22px' : '18px',
                color: club.secondary
              }}
            >
              {matchData.matchDate} • vs {matchData.opponent}
            </p>
            <div className="flex items-center gap-4">
              <div 
                className="px-6 py-3 rounded-xl font-bold"
                style={{
                  backgroundColor: club.secondary,
                  color: club.primary,
                  fontSize: isStory ? '28px' : '24px'
                }}
              >
                {matchData.totalScore}
              </div>
              <div 
                className="font-bold"
                style={{
                  fontSize: isStory ? '24px' : '20px',
                  color: club.secondary
                }}
              >
                {matchData.result}
              </div>
            </div>
          </div>
        </Item>

        {/* Top Performers */}
        <div className="flex-1 grid grid-cols-1 gap-6">
          {/* Batting */}
          <Item variants={animated ? itemVariants : undefined}>
            <div 
              className="rounded-2xl p-6 h-full"
              style={{
                backgroundColor: `${club.secondary}18`,
                backdropFilter: 'blur(10px)'
              }}
            >
              <h3 
                className="font-bold mb-4"
                style={{
                  fontSize: isStory ? '28px' : '24px',
                  color: club.secondary
                }}
              >
                🏏 Top Batting Performances
              </h3>
              <div className="space-y-3">
                {matchData.topBatters.map((batter, idx) => (
                  <motion.div
                    key={idx}
                    className="flex items-center justify-between p-4 rounded-xl"
                    style={{
                      backgroundColor: `${club.secondary}15`
                    }}
                    initial={animated ? { x: -50, opacity: 0 } : undefined}
                    animate={animated ? { x: 0, opacity: 1 } : undefined}
                    transition={animated ? { delay: 0.5 + idx * 0.15 } : undefined}
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-12 h-12 rounded-full flex items-center justify-center font-bold"
                        style={{
                          backgroundColor: club.secondary,
                          color: club.primary,
                          fontSize: '20px'
                        }}
                      >
                        {idx + 1}
                      </div>
                      <div>
                        <div 
                          className="font-bold"
                          style={{
                            fontSize: isStory ? '22px' : '18px',
                            color: club.secondary
                          }}
                        >
                          {batter.playerName}
                        </div>
                        <div 
                          className="opacity-75"
                          style={{
                            fontSize: isStory ? '16px' : '14px',
                            color: club.secondary
                          }}
                        >
                          {batter.balls} balls • {batter.fours}×4 • {batter.sixes}×6
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div 
                        className="font-bold"
                        style={{
                          fontSize: isStory ? '32px' : '28px',
                          color: club.secondary
                        }}
                      >
                        {batter.runs}
                      </div>
                      <div 
                        className="opacity-75"
                        style={{
                          fontSize: isStory ? '16px' : '14px',
                          color: club.secondary
                        }}
                      >
                        SR: {batter.strikeRate.toFixed(1)}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </Item>

          {/* Bowling */}
          <Item variants={animated ? itemVariants : undefined}>
            <div 
              className="rounded-2xl p-6 h-full"
              style={{
                backgroundColor: `${club.secondary}18`,
                backdropFilter: 'blur(10px)'
              }}
            >
              <h3 
                className="font-bold mb-4"
                style={{
                  fontSize: isStory ? '28px' : '24px',
                  color: club.secondary
                }}
              >
                ⚡ Top Bowling Performances
              </h3>
              <div className="space-y-3">
                {matchData.topBowlers.map((bowler, idx) => (
                  <motion.div
                    key={idx}
                    className="flex items-center justify-between p-4 rounded-xl"
                    style={{
                      backgroundColor: `${club.secondary}15`
                    }}
                    initial={animated ? { x: -50, opacity: 0 } : undefined}
                    animate={animated ? { x: 0, opacity: 1 } : undefined}
                    transition={animated ? { delay: 0.8 + idx * 0.15 } : undefined}
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-12 h-12 rounded-full flex items-center justify-center font-bold"
                        style={{
                          backgroundColor: club.secondary,
                          color: club.primary,
                          fontSize: '20px'
                        }}
                      >
                        {idx + 1}
                      </div>
                      <div>
                        <div 
                          className="font-bold"
                          style={{
                            fontSize: isStory ? '22px' : '18px',
                            color: club.secondary
                          }}
                        >
                          {bowler.playerName}
                        </div>
                        <div 
                          className="opacity-75"
                          style={{
                            fontSize: isStory ? '16px' : '14px',
                            color: club.secondary
                          }}
                        >
                          {bowler.overs} overs • {bowler.maidens} maidens
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div 
                        className="font-bold"
                        style={{
                          fontSize: isStory ? '32px' : '28px',
                          color: club.secondary
                        }}
                      >
                        {bowler.wickets}/{bowler.runs}
                      </div>
                      <div 
                        className="opacity-75"
                        style={{
                          fontSize: isStory ? '16px' : '14px',
                          color: club.secondary
                        }}
                      >
                        Econ: {bowler.economy.toFixed(2)}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </Item>
        </div>

        {/* Footer watermark */}
        <Item
          className="mt-8 text-center opacity-60"
          variants={animated ? itemVariants : undefined}
        >
          <p 
            style={{
              fontSize: isStory ? '18px' : '16px',
              color: club.secondary
            }}
          >
            Peel Cricket Association • PlayHQ
          </p>
        </Item>
      </div>
    </Container>
  );
}
