import { useState } from 'react';
import { clubsData } from '../utils/clubData';
import { MatchData, BattingPerformance, BowlingPerformance } from '../types/matchTypes';
import { Plus, Trash2 } from 'lucide-react';

interface MatchDataFormProps {
  matchData: MatchData;
  onUpdate: (data: MatchData) => void;
}

export function MatchDataForm({ matchData, onUpdate }: MatchDataFormProps) {
  const [localData, setLocalData] = useState<MatchData>(matchData);

  const handleChange = (field: keyof MatchData, value: string) => {
    const updated = { ...localData, [field]: value };
    setLocalData(updated);
    onUpdate(updated);
  };

  const handleBatterChange = (index: number, field: keyof BattingPerformance, value: string | number) => {
    const updated = { ...localData };
    updated.topBatters[index] = {
      ...updated.topBatters[index],
      [field]: value
    };
    
    // Auto-calculate strike rate
    if (field === 'runs' || field === 'balls') {
      const runs = field === 'runs' ? Number(value) : updated.topBatters[index].runs;
      const balls = field === 'balls' ? Number(value) : updated.topBatters[index].balls;
      if (balls > 0) {
        updated.topBatters[index].strikeRate = (runs / balls) * 100;
      }
    }
    
    setLocalData(updated);
    onUpdate(updated);
  };

  const handleBowlerChange = (index: number, field: keyof BowlingPerformance, value: string | number) => {
    const updated = { ...localData };
    updated.topBowlers[index] = {
      ...updated.topBowlers[index],
      [field]: value
    };
    
    // Auto-calculate economy
    if (field === 'runs' || field === 'overs') {
      const runs = field === 'runs' ? Number(value) : updated.topBowlers[index].runs;
      const overs = field === 'overs' ? Number(value) : updated.topBowlers[index].overs;
      if (overs > 0) {
        updated.topBowlers[index].economy = runs / overs;
      }
    }
    
    setLocalData(updated);
    onUpdate(updated);
  };

  const addBatter = () => {
    const updated = { ...localData };
    updated.topBatters.push({
      playerName: '',
      runs: 0,
      balls: 0,
      fours: 0,
      sixes: 0,
      strikeRate: 0
    });
    setLocalData(updated);
    onUpdate(updated);
  };

  const removeBatter = (index: number) => {
    const updated = { ...localData };
    updated.topBatters.splice(index, 1);
    setLocalData(updated);
    onUpdate(updated);
  };

  const addBowler = () => {
    const updated = { ...localData };
    updated.topBowlers.push({
      playerName: '',
      overs: 0,
      maidens: 0,
      runs: 0,
      wickets: 0,
      economy: 0
    });
    setLocalData(updated);
    onUpdate(updated);
  };

  const removeBowler = (index: number) => {
    const updated = { ...localData };
    updated.topBowlers.splice(index, 1);
    setLocalData(updated);
    onUpdate(updated);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 max-h-[800px] overflow-y-auto">
      <h3 className="font-bold mb-6">Match Details</h3>
      
      {/* Basic Info */}
      <div className="space-y-4 mb-6">
        <div>
          <label className="block mb-2 opacity-70">Select Club</label>
          <select
            value={localData.clubSlug}
            onChange={(e) => handleChange('clubSlug', e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
          >
            {clubsData.map((club) => (
              <option key={club.slug} value={club.slug}>
                {club.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block mb-2 opacity-70">Match Title</label>
          <input
            type="text"
            value={localData.matchTitle}
            onChange={(e) => handleChange('matchTitle', e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
            placeholder="e.g., Round 5 - A Grade"
          />
        </div>

        <div>
          <label className="block mb-2 opacity-70">Match Date</label>
          <input
            type="text"
            value={localData.matchDate}
            onChange={(e) => handleChange('matchDate', e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
            placeholder="e.g., 5th June 2026"
          />
        </div>

        <div>
          <label className="block mb-2 opacity-70">Opponent</label>
          <input
            type="text"
            value={localData.opponent}
            onChange={(e) => handleChange('opponent', e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
            placeholder="e.g., Mandurah Cricket Club"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block mb-2 opacity-70">Total Score</label>
            <input
              type="text"
              value={localData.totalScore}
              onChange={(e) => handleChange('totalScore', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="e.g., 7/245"
            />
          </div>
          <div>
            <label className="block mb-2 opacity-70">Result</label>
            <input
              type="text"
              value={localData.result}
              onChange={(e) => handleChange('result', e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="e.g., Won by 5 wickets"
            />
          </div>
        </div>
      </div>

      {/* Batting Performances */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-bold">Top Batting Performances</h4>
          <button
            onClick={addBatter}
            className="flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
          >
            <Plus size={16} />
            Add Batter
          </button>
        </div>

        <div className="space-y-4">
          {localData.topBatters.map((batter, idx) => (
            <div key={idx} className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="font-bold">#{idx + 1}</span>
                {localData.topBatters.length > 1 && (
                  <button
                    onClick={() => removeBatter(idx)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  value={batter.playerName}
                  onChange={(e) => handleBatterChange(idx, 'playerName', e.target.value)}
                  className="col-span-2 px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Player Name"
                />
                <input
                  type="number"
                  value={batter.runs}
                  onChange={(e) => handleBatterChange(idx, 'runs', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Runs"
                />
                <input
                  type="number"
                  value={batter.balls}
                  onChange={(e) => handleBatterChange(idx, 'balls', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Balls"
                />
                <input
                  type="number"
                  value={batter.fours}
                  onChange={(e) => handleBatterChange(idx, 'fours', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="4s"
                />
                <input
                  type="number"
                  value={batter.sixes}
                  onChange={(e) => handleBatterChange(idx, 'sixes', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="6s"
                />
              </div>
              <div className="mt-2 text-sm opacity-60">
                Strike Rate: {batter.strikeRate.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bowling Performances */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-bold">Top Bowling Performances</h4>
          <button
            onClick={addBowler}
            className="flex items-center gap-2 px-3 py-2 bg-purple-100 text-purple-600 rounded-lg hover:bg-purple-200 transition-colors"
          >
            <Plus size={16} />
            Add Bowler
          </button>
        </div>

        <div className="space-y-4">
          {localData.topBowlers.map((bowler, idx) => (
            <div key={idx} className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="font-bold">#{idx + 1}</span>
                {localData.topBowlers.length > 1 && (
                  <button
                    onClick={() => removeBowler(idx)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  value={bowler.playerName}
                  onChange={(e) => handleBowlerChange(idx, 'playerName', e.target.value)}
                  className="col-span-2 px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Player Name"
                />
                <input
                  type="number"
                  value={bowler.overs}
                  onChange={(e) => handleBowlerChange(idx, 'overs', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Overs"
                />
                <input
                  type="number"
                  value={bowler.maidens}
                  onChange={(e) => handleBowlerChange(idx, 'maidens', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Maidens"
                />
                <input
                  type="number"
                  value={bowler.runs}
                  onChange={(e) => handleBowlerChange(idx, 'runs', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Runs"
                />
                <input
                  type="number"
                  value={bowler.wickets}
                  onChange={(e) => handleBowlerChange(idx, 'wickets', Number(e.target.value))}
                  className="px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="Wickets"
                />
              </div>
              <div className="mt-2 text-sm opacity-60">
                Economy: {bowler.economy.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
