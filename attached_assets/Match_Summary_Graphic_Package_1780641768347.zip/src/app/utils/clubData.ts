export interface Club {
  name: string;
  slug: string;
  orgId: string;
  role: string;
  primary: string;
  secondary: string;
  tertiary: string;
  quaternary?: string;
  logo: string;
}

// Parse club data from the CSV content
export const clubsData: Club[] = [
  {
    name: "Peel Cricket Association",
    slug: "peel-cricket-association-inc",
    orgId: "c8b4654f",
    role: "Association",
    primary: "#93182C",
    secondary: "#65B6C5",
    tertiary: "#D82225",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/c8b4654f-7682-4c36-b8fb-6df00212a6d4/1685337770470/logo.jpg"
  },
  {
    name: "Halls Head Cricket Club",
    slug: "halls-head-cricket-club",
    orgId: "5fe82f6b",
    role: "Member",
    primary: "#333F48",
    secondary: "#FBAC27",
    tertiary: "#42342B",
    quaternary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/5fe82f6b-ee78-4232-9910-f5343547c1c3/1687781014605/logo.png"
  },
  {
    name: "White Knights Baldivis Cricket Club",
    slug: "white-knights-baldivis-cricket-club",
    orgId: "ce4b755c",
    role: "Member",
    primary: "#080862",
    secondary: "#FFFFFF",
    tertiary: "#C9A24B",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/ce4b755c-9f9a-4e2d-a704-9410e401f32c/1728475140615/logo.jpg"
  },
  {
    name: "Waroona Cricket Club",
    slug: "waroona-cricket-club",
    orgId: "beff7c93",
    role: "Member",
    primary: "#020202",
    secondary: "#FFFFFF",
    tertiary: "#272727",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/beff7c93-60a7-4364-8a4f-dd450a99a3c7/1689172392105/logo.jpg"
  },
  {
    name: "Shoalwater Bay Cricket Club",
    slug: "shoalwater-bay-cricket-club",
    orgId: "004d3d9f",
    role: "Member",
    primary: "#680100",
    secondary: "#FCD803",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/004d3d9f-b518-4843-bbd2-78392844073e/1687068606779/logo.png"
  },
  {
    name: "Mandurah Cricket Club",
    slug: "mandurah-cricket-club",
    orgId: "84fe5d06",
    role: "Member",
    primary: "#162850",
    secondary: "#FFFFFF",
    tertiary: "#384666",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/84fe5d06-5eeb-4fe5-85d1-bf3fd59956aa/1689819925822/logo.png"
  },
  {
    name: "Warnbro Swans Cricket Club",
    slug: "warnbro-swans-cricket-club",
    orgId: "a34f889b",
    role: "Member",
    primary: "#020202",
    secondary: "#FEF203",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/a34f889b-0ee6-407d-ad6a-ff867a1c8b30/1686818756568/logo.jpg"
  },
  {
    name: "Pinjarra Cricket Club",
    slug: "pinjarra-cricket-club",
    orgId: "005087b1",
    role: "Member",
    primary: "#FFCE2F",
    secondary: "#000000",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/005087b1-3ecb-4e33-8635-f731a54c6a7e/1686889595900/logo.png"
  },
  {
    name: "Singleton Irwinians Cricket Club",
    slug: "singleton-irwinians-cricket-club",
    orgId: "310ffe54",
    role: "Member",
    primary: "#030206",
    secondary: "#F86B06",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/310ffe54-bd81-4b03-8a15-f7b3e1f97ec3/1757554635167/logo.jpg"
  },
  {
    name: "Rockingham Hornets Cricket Club",
    slug: "rockingham-hornets-cricket-club",
    orgId: "218c4b17",
    role: "Member",
    primary: "#014602",
    secondary: "#E8B402",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/218c4b17-6214-4d97-bf9c-3dffe60c2202/1686818105336/logo.jpg"
  },
  {
    name: "Secret Harbour Dockers Cricket Club",
    slug: "secret-harbour-dockers-cricket-club",
    orgId: "47bee109",
    role: "Member",
    primary: "#271E54",
    secondary: "#493775",
    tertiary: "#764D9A",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/47bee109-8aa0-41d1-adb3-f7c835216bab/1728693382613/logo.jpg"
  },
  {
    name: "South Mandurah Cricket Club",
    slug: "south-mandurah-cricket-club",
    orgId: "b9d1dea7",
    role: "Member",
    primary: "#FBC211",
    secondary: "#1714D6",
    tertiary: "#FFFFFF",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/b9d1dea7-ea47-4c49-b7a5-0e87141d9644/1687664961809/logo.jpg"
  },
  {
    name: "Murdoch University Melville Cricket Club",
    slug: "murdoch-university-melville-cricket-club",
    orgId: "9b047d52",
    role: "Colts only",
    primary: "#2A2466",
    secondary: "#953336",
    tertiary: "#9A9A9A",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/9b047d52-35ab-4042-9265-17496a7ce212/1730419356851/logo.jpg"
  },
  {
    name: "SJ Blues Cricket Club",
    slug: "sj-blues-cricket-club",
    orgId: "1051340b",
    role: "Visiting (Female A 2025/26)",
    primary: "#E4312A",
    secondary: "#FFFFFF",
    tertiary: "#1B1F4B",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/1051340b-60fb-41d5-9e28-c04a2506beef/1687875426276/logo.jpg"
  },
  {
    name: "Rockingham Mandurah Cricket Club (Mariners RMDCC)",
    slug: "rockingham-mandurah-cricket-club",
    orgId: "c781d962",
    role: "Visiting (PPL T20 2024/25)",
    primary: "#882435",
    secondary: "#73C9E0",
    tertiary: "#E2231A",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/c781d962-3078-4662-9ba7-e053d900c750/1690445947031/logo.jpg"
  },
  {
    name: "Harvey Benger Cricket Club",
    slug: "harvey-benger-cricket-club-inc",
    orgId: "769cd605",
    role: "Visiting (PPL T20 2024/25)",
    primary: "#005502",
    secondary: "#020202",
    tertiary: "#800001",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/769cd605-252b-4cf8-865c-f4b37cabe5c5/1688090649001/logo.png"
  },
  {
    name: "Curtin Victoria Park Cricket Club",
    slug: "curtin-victoria-park-cricket-club",
    orgId: "32a36d4f",
    role: "Visiting (PPL T20 2023/24)",
    primary: "#231F20",
    secondary: "#D0A44B",
    tertiary: "#ED1B24",
    logo: "https://res.cloudinary.com/playhq/image/upload/h_128,w_128/v1/production/ca/32a36d4f-ab15-414d-9bcc-66f23e21f0ec/1759712248765/logo.jpg"
  }
];

export const getClubBySlug = (slug: string): Club | undefined => {
  return clubsData.find(club => club.slug === slug);
};

export const getClubByName = (name: string): Club | undefined => {
  return clubsData.find(club => club.name === name);
};
