import html2canvas from 'html2canvas';

export type ExportFormat = 'square' | 'portrait' | 'story';

export const formatDimensions: Record<ExportFormat, { width: number; height: number; label: string }> = {
  square: { width: 1080, height: 1080, label: 'Square (1:1)' },
  portrait: { width: 1080, height: 1350, label: 'Portrait (4:5)' },
  story: { width: 1080, height: 1920, label: 'Story/TikTok (9:16)' }
};

export const exportAsImage = async (
  element: HTMLElement,
  format: ExportFormat,
  filename: string
): Promise<void> => {
  const dimensions = formatDimensions[format];
  
  // Capture the element as canvas
  const canvas = await html2canvas(element, {
    width: dimensions.width,
    height: dimensions.height,
    scale: 2,
    backgroundColor: null,
    logging: false,
    useCORS: true,
    allowTaint: true
  });

  // Convert to blob and download
  canvas.toBlob((blob) => {
    if (blob) {
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `${filename}-${format}.png`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    }
  }, 'image/png');
};

export const startVideoRecording = (
  canvas: HTMLCanvasElement,
  duration: number = 5000
): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const stream = canvas.captureStream(30); // 30 FPS
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: 'video/webm;codecs=vp9',
      videoBitsPerSecond: 5000000
    });

    const chunks: Blob[] = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunks.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      resolve(blob);
    };

    mediaRecorder.onerror = (error) => {
      reject(error);
    };

    mediaRecorder.start();

    // Stop recording after duration
    setTimeout(() => {
      mediaRecorder.stop();
    }, duration);
  });
};

export const downloadVideo = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.download = `${filename}.webm`;
  link.href = url;
  link.click();
  URL.revokeObjectURL(url);
};
