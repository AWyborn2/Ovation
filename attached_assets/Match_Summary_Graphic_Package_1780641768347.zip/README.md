
  # Match Summary Graphic Package

  This is a code bundle for Match Summary Graphic Package. The original project is available at https://www.figma.com/design/zBS4pLKfJd7xGgWH4v6bPW/Match-Summary-Graphic-Package.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  