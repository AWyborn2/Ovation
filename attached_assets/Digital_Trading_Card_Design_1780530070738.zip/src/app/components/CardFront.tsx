import { Download, Star } from 'lucide-react';
import { motion } from 'motion/react';
import playerImage from '../../imports/7763427.jpg';
import clubLogo from '../../imports/HHCC_logo.png';

interface PlayerStats {
  matches: number;
  runs: number;
  battingAverage: number;
  strikeRate: number;
  centuries: number;
  halfCenturies: number;
  wickets: number;
  bowlingAverage: number;
  economy: number;
  maidens: number;
  fiveWickets: number;
}

interface PlayerData {
  name: string;
  number: number;
  country: string;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  rating: number;
  debutYear: number;
  stats: PlayerStats;
  additionalStats: {
    highestScore: number;
    bestBowling: string;
    catches: number;
    stumpings: number;
    runOuts: number;
  };
  achievements: {
    premierships: number[];
    awards: string[];
    records: string[];
  };
}

interface CardFrontProps {
  player: PlayerData;
  onDownload: () => void;
}

export function CardFront({ player, onDownload }: CardFrontProps) {
  // Dynamic stats based on player role
  const getMainStats = () => {
    switch (player.role) {
      case 'Batsman':
      case 'Wicket-Keeper':
        return [
          { label: 'Matches', value: player.stats.matches, color: 'primary' },
          { label: 'Runs', value: player.stats.runs.toLocaleString(), color: 'primary' },
          { label: 'Average', value: player.stats.battingAverage, color: 'secondary' },
          { label: 'S/R', value: player.stats.strikeRate, color: 'secondary' },
        ];
      case 'Bowler':
        return [
          { label: 'Matches', value: player.stats.matches, color: 'primary' },
          { label: 'Wickets', value: player.stats.wickets, color: 'primary' },
          { label: 'Average', value: player.stats.bowlingAverage, color: 'secondary' },
          { label: 'Economy', value: player.stats.economy, color: 'secondary' },
        ];
      case 'All-Rounder':
        return [
          { label: 'Runs', value: player.stats.runs.toLocaleString(), color: 'primary' },
          { label: 'Bat Avg', value: player.stats.battingAverage, color: 'primary' },
          { label: 'Wickets', value: player.stats.wickets, color: 'secondary' },
          { label: 'Bowl Avg', value: player.stats.bowlingAverage, color: 'secondary' },
        ];
      default:
        return [];
    }
  };

  const getPerformanceBars = () => {
    switch (player.role) {
      case 'Batsman':
      case 'Wicket-Keeper':
        return [
          { label: 'Centuries', value: player.stats.centuries, max: 60, color: 'primary' },
          { label: 'Half-Centuries', value: player.stats.halfCenturies, max: 80, color: 'secondary' },
        ];
      case 'Bowler':
        return [
          { label: '5-Wicket Hauls', value: player.stats.fiveWickets, max: 20, color: 'primary' },
          { label: 'Maidens', value: player.stats.maidens, max: 50, color: 'secondary' },
        ];
      case 'All-Rounder':
        return [
          { label: 'Centuries', value: player.stats.centuries, max: 40, color: 'primary' },
          { label: '5-Wicket Hauls', value: player.stats.fiveWickets, max: 15, color: 'secondary' },
        ];
      default:
        return [];
    }
  };

  const mainStats = getMainStats();
  const performanceBars = getPerformanceBars();

  return (
    <div className="absolute w-full h-full backface-hidden">
      <div className="relative bg-gradient-to-br from-[#333F48] to-[#333F48] rounded-3xl shadow-2xl overflow-hidden h-full">
        {/* Header with number */}
        <div className="relative h-16 bg-gradient-to-r from-[#333F48] to-[#333F48] border-b-4 border-[#FBAC27]">
          <div className="absolute right-0 top-0 w-24 h-24 bg-gradient-to-bl from-[#FBAC27] to-[#FBAC27] transform rotate-45 translate-x-8 -translate-y-8"></div>
          <div className="absolute right-4 top-3 z-10">
            <span className="text-white font-black text-3xl">{player.number}</span>
          </div>
          <div className="px-4 py-2 flex items-center gap-3">
            <img src={clubLogo} alt="Halls Head Cricket Club" className="w-12 h-12 object-contain" />
            <span className="text-white/90 uppercase tracking-wider text-xs font-semibold">
              Halls Head Cricket Club
            </span>
          </div>
        </div>

        {/* Player Image Section */}
        <div className="relative h-80 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-[#333F48] via-transparent to-transparent z-10"></div>
          <img
            src={playerImage}
            alt={player.name}
            className="w-full h-full object-cover object-top"
          />

          {/* Badge */}
          <div className="absolute top-4 right-4 z-20 bg-[#333F48] border-2 border-[#FBAC27] rounded-full px-3 py-1">
            <span className="text-white text-xs uppercase tracking-wider font-bold">
              {player.role}
            </span>
          </div>

          {/* Country Badge */}
          <div className="absolute bottom-4 right-4 z-20 bg-[#333F48] border-2 border-[#FBAC27] rounded-lg px-3 py-2">
            <span className="text-white text-xs uppercase tracking-wider font-bold">
              {player.country}
            </span>
          </div>
        </div>

        {/* Player Name Bar */}
        <div className="relative -mt-8 z-20 mx-4">
          <div className="bg-gradient-to-r from-[#FBAC27] to-[#FBAC27] rounded-lg px-4 py-3 shadow-lg">
            <div className="flex items-center justify-between">
              <h2 className="text-[#333F48] font-black text-xl uppercase tracking-wide">
                {player.name}
              </h2>
              <button
                onClick={onDownload}
                className="bg-[#333F48]/30 hover:bg-[#333F48]/50 transition-colors rounded-full p-2"
              >
                <Download className="w-4 h-4 text-[#333F48]" />
              </button>
            </div>
          </div>
        </div>

        {/* Rating Stars */}
        <div className="px-4 mt-3 flex items-center gap-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-5 h-5 ${
                i < player.rating
                  ? 'fill-[#ffd700] text-[#ffd700]'
                  : 'fill-gray-600 text-gray-600'
              }`}
            />
          ))}
        </div>

        {/* Main Stats Grid */}
        <div className="px-4 mt-4 grid grid-cols-4 gap-2">
          {mainStats.map((stat, index) => (
            <div
              key={index}
              className={`${
                stat.color === 'primary'
                  ? 'bg-[#FBAC27]/10 border border-[#FBAC27]/30'
                  : 'bg-[#333F48]/50 border border-[#333F48]'
              } rounded-lg p-2`}
            >
              <div className="text-[#FBAC27] text-xs uppercase font-semibold mb-1">
                {stat.label}
              </div>
              <div className="text-white font-black text-lg">{stat.value}</div>
            </div>
          ))}
        </div>

        {/* Performance Bars */}
        <div className="px-4 mt-4 space-y-2">
          {performanceBars.map((bar, index) => (
            <div key={index}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-white/70 uppercase font-semibold">{bar.label}</span>
                <span className="text-white font-bold">{bar.value}</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    bar.color === 'primary'
                      ? 'bg-gradient-to-r from-[#FBAC27] to-[#FBAC27]'
                      : 'bg-gradient-to-r from-[#333F48] to-[#333F48]'
                  }`}
                  style={{ width: `${Math.min((bar.value / bar.max) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Tap to Flip Hint */}
        <div className="px-4 mt-6 mb-4">
          <div className="bg-[#FBAC27]/20 border border-[#FBAC27]/40 rounded-lg px-4 py-2 text-center">
            <span className="text-[#FBAC27] text-xs uppercase font-bold tracking-wider">
              Tap to view full stats
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
