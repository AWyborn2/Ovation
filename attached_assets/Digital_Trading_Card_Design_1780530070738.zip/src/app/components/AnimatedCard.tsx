import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, Trophy, Award, Target } from 'lucide-react';
import playerImage from '../../imports/7763427.jpg';
import clubLogo from '../../imports/HHCC_logo.png';

interface PlayerStats {
  matches: number;
  runs: number;
  battingAverage: number;
  strikeRate: number;
  centuries: number;
  halfCenturies: number;
  wickets: number;
  bowlingAverage: number;
  economy: number;
  maidens: number;
  fiveWickets: number;
}

interface PlayerData {
  name: string;
  number: number;
  country: string;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  rating: number;
  debutYear: number;
  stats: PlayerStats;
  additionalStats: {
    highestScore: number;
    bestBowling: string;
    catches: number;
    stumpings: number;
    runOuts: number;
  };
  achievements: {
    premierships: number[];
    awards: string[];
    records: string[];
  };
}

interface AnimatedCardProps {
  player: PlayerData;
  isPlaying: boolean;
  onComplete: () => void;
}

type AnimationPhase =
  | 'intro'
  | 'mainStats'
  | 'batting'
  | 'bowling'
  | 'fielding'
  | 'premierships'
  | 'awards'
  | 'records'
  | 'outro';

export function AnimatedCard({ player, isPlaying, onComplete }: AnimatedCardProps) {
  const [phase, setPhase] = useState<AnimationPhase>('intro');
  const [highlightIndex, setHighlightIndex] = useState(0);

  useEffect(() => {
    if (!isPlaying) {
      setPhase('intro');
      setHighlightIndex(0);
      return;
    }

    const timeline = [
      { phase: 'intro', duration: 2000 },
      { phase: 'mainStats', duration: 3000 },
      { phase: 'batting', duration: 2500 },
      { phase: 'bowling', duration: 2500 },
      { phase: 'fielding', duration: 2000 },
      { phase: 'premierships', duration: 2000 },
      { phase: 'awards', duration: 2000 },
      { phase: 'records', duration: 2000 },
      { phase: 'outro', duration: 2000 },
    ];

    let currentTime = 0;
    const timers: NodeJS.Timeout[] = [];

    timeline.forEach(({ phase: nextPhase, duration }) => {
      const timer = setTimeout(() => {
        setPhase(nextPhase as AnimationPhase);
        setHighlightIndex(0);
      }, currentTime);
      timers.push(timer);
      currentTime += duration;
    });

    // Complete callback
    const completeTimer = setTimeout(() => {
      onComplete();
    }, currentTime);
    timers.push(completeTimer);

    return () => {
      timers.forEach(clearTimeout);
    };
  }, [isPlaying, onComplete]);

  const getMainStats = () => {
    switch (player.role) {
      case 'Batsman':
      case 'Wicket-Keeper':
        return [
          { label: 'Matches', value: player.stats.matches },
          { label: 'Runs', value: player.stats.runs.toLocaleString() },
          { label: 'Average', value: player.stats.battingAverage },
          { label: 'S/R', value: player.stats.strikeRate },
        ];
      case 'Bowler':
        return [
          { label: 'Matches', value: player.stats.matches },
          { label: 'Wickets', value: player.stats.wickets },
          { label: 'Average', value: player.stats.bowlingAverage },
          { label: 'Economy', value: player.stats.economy },
        ];
      case 'All-Rounder':
        return [
          { label: 'Runs', value: player.stats.runs.toLocaleString() },
          { label: 'Bat Avg', value: player.stats.battingAverage },
          { label: 'Wickets', value: player.stats.wickets },
          { label: 'Bowl Avg', value: player.stats.bowlingAverage },
        ];
      default:
        return [];
    }
  };

  const showIntro = phase === 'intro' || phase === 'outro';
  const showStats = phase !== 'intro' && phase !== 'outro';

  return (
    <div className="relative w-full h-full">
      <div className="relative bg-gradient-to-br from-[#333F48] to-[#333F48] rounded-3xl shadow-2xl overflow-hidden h-full">
        {/* Header */}
        <div className="relative h-16 bg-gradient-to-r from-[#333F48] to-[#333F48] border-b-4 border-[#FBAC27]">
          <div className="absolute right-0 top-0 w-24 h-24 bg-gradient-to-bl from-[#FBAC27] to-[#FBAC27] transform rotate-45 translate-x-8 -translate-y-8"></div>
          <motion.div
            className="absolute right-4 top-3 z-10"
            animate={{ scale: phase === 'intro' ? [1, 1.2, 1] : 1 }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-white font-black text-3xl">{player.number}</span>
          </motion.div>
          <div className="px-4 py-2 flex items-center gap-3">
            <img src={clubLogo} alt="Halls Head Cricket Club" className="w-12 h-12 object-contain" />
            <span className="text-white/90 uppercase tracking-wider text-xs font-semibold">
              Halls Head Cricket Club
            </span>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {showIntro && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative"
            >
              {/* Player Image */}
              <div className="relative h-80 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-[#333F48] via-transparent to-transparent z-10"></div>
                <motion.img
                  src={playerImage}
                  alt={player.name}
                  className="w-full h-full object-cover object-top"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />

                {/* Badge */}
                <motion.div
                  className="absolute top-4 right-4 z-20 bg-[#333F48] border-2 border-[#FBAC27] rounded-full px-3 py-1"
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <span className="text-white text-xs uppercase tracking-wider font-bold">
                    {player.role}
                  </span>
                </motion.div>

                {/* Country Badge */}
                <motion.div
                  className="absolute bottom-4 right-4 z-20 bg-[#333F48] border-2 border-[#FBAC27] rounded-lg px-3 py-2"
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  <span className="text-white text-xs uppercase tracking-wider font-bold">
                    {player.country}
                  </span>
                </motion.div>
              </div>

              {/* Player Name */}
              <motion.div
                className="relative -mt-8 z-20 mx-4"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <div className="bg-gradient-to-r from-[#FBAC27] to-[#FBAC27] rounded-lg px-4 py-3 shadow-lg">
                  <h2 className="text-[#333F48] font-black text-xl uppercase tracking-wide text-center">
                    {player.name}
                  </h2>
                </div>
              </motion.div>

              {/* Rating Stars */}
              <motion.div
                className="px-4 mt-3 flex items-center justify-center gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
              >
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1 + i * 0.1 }}
                  >
                    <Star
                      className={`w-5 h-5 ${
                        i < player.rating
                          ? 'fill-[#ffd700] text-[#ffd700]'
                          : 'fill-gray-600 text-gray-600'
                      }`}
                    />
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          )}

          {phase === 'mainStats' && (
            <motion.div
              key="mainStats"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center">
                Key Statistics
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {getMainStats().map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: index * 0.3 }}
                    className="bg-[#FBAC27]/10 border-2 border-[#FBAC27] rounded-lg p-4"
                  >
                    <div className="text-[#FBAC27] text-sm uppercase font-semibold mb-2">
                      {stat.label}
                    </div>
                    <motion.div
                      className="text-white font-black text-3xl"
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ delay: index * 0.3 + 0.2, duration: 0.3 }}
                    >
                      {stat.value}
                    </motion.div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {phase === 'batting' && (player.role === 'Batsman' || player.role === 'All-Rounder' || player.role === 'Wicket-Keeper') && (
            <motion.div
              key="batting"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center flex items-center justify-center gap-2">
                <Target className="w-5 h-5" />
                Batting Performance
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Total Runs', value: player.stats.runs.toLocaleString() },
                  { label: 'Average', value: player.stats.battingAverage },
                  { label: 'Strike Rate', value: player.stats.strikeRate },
                  { label: 'High Score', value: player.additionalStats.highestScore },
                  { label: 'Centuries', value: player.stats.centuries },
                  { label: 'Half-Centuries', value: player.stats.halfCenturies },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, rotate: -10 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: index * 0.2 }}
                    className="bg-[#333F48]/80 rounded-lg p-3 border border-[#FBAC27]/40"
                  >
                    <div className="text-white/70 text-xs uppercase mb-1">{stat.label}</div>
                    <div className="text-white font-black text-2xl">{stat.value}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {phase === 'bowling' && (player.role === 'Bowler' || player.role === 'All-Rounder') && (
            <motion.div
              key="bowling"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center">
                Bowling Performance
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Wickets', value: player.stats.wickets },
                  { label: 'Average', value: player.stats.bowlingAverage },
                  { label: 'Economy', value: player.stats.economy },
                  { label: 'Best', value: player.additionalStats.bestBowling },
                  { label: '5W Hauls', value: player.stats.fiveWickets },
                  { label: 'Maidens', value: player.stats.maidens },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, rotate: 10 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: index * 0.2 }}
                    className="bg-[#333F48]/80 rounded-lg p-3 border border-[#FBAC27]/40"
                  >
                    <div className="text-white/70 text-xs uppercase mb-1">{stat.label}</div>
                    <div className="text-white font-black text-2xl">{stat.value}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {phase === 'fielding' && (
            <motion.div
              key="fielding"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center">
                Fielding Stats
              </h3>
              <div className="grid grid-cols-3 gap-3">
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-[#333F48]/80 rounded-lg p-4 border-2 border-[#FBAC27]/40"
                >
                  <div className="text-white/70 text-sm uppercase mb-1">Catches</div>
                  <div className="text-white font-black text-3xl">{player.additionalStats.catches}</div>
                </motion.div>
                {player.role === 'Wicket-Keeper' && (
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="bg-[#333F48]/80 rounded-lg p-4 border-2 border-[#FBAC27]/40"
                  >
                    <div className="text-white/70 text-sm uppercase mb-1">Stumpings</div>
                    <div className="text-white font-black text-3xl">{player.additionalStats.stumpings}</div>
                  </motion.div>
                )}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="bg-[#333F48]/80 rounded-lg p-4 border-2 border-[#FBAC27]/40"
                >
                  <div className="text-white/70 text-sm uppercase mb-1">Run Outs</div>
                  <div className="text-white font-black text-3xl">{player.additionalStats.runOuts}</div>
                </motion.div>
              </div>
            </motion.div>
          )}

          {phase === 'premierships' && player.achievements.premierships.length > 0 && (
            <motion.div
              key="premierships"
              initial={{ opacity: 0, rotateY: 90 }}
              animate={{ opacity: 1, rotateY: 0 }}
              exit={{ opacity: 0, rotateY: -90 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center flex items-center justify-center gap-2">
                <Trophy className="w-6 h-6" />
                Premierships
              </h3>
              <div className="flex flex-wrap gap-3 justify-center">
                {player.achievements.premierships.map((year, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: index * 0.2, type: 'spring' }}
                    className="bg-[#FBAC27] text-[#333F48] px-6 py-3 rounded-full font-black text-2xl shadow-lg"
                  >
                    {year}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {phase === 'awards' && player.achievements.awards.length > 0 && (
            <motion.div
              key="awards"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center flex items-center justify-center gap-2">
                <Award className="w-6 h-6" />
                Awards
              </h3>
              <div className="space-y-3">
                {player.achievements.awards.map((award, index) => (
                  <motion.div
                    key={index}
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.3 }}
                    className="bg-[#333F48]/80 rounded-lg p-4 border-l-4 border-[#FBAC27]"
                  >
                    <div className="text-white text-base">{award}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {phase === 'records' && player.achievements.records.length > 0 && (
            <motion.div
              key="records"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="px-4 py-6"
            >
              <h3 className="text-[#FBAC27] text-lg uppercase font-bold mb-4 text-center">
                Club Records
              </h3>
              <div className="space-y-3">
                {player.achievements.records.map((record, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: index * 0.4 }}
                    className="bg-[#333F48]/80 rounded-lg p-3 border border-[#FBAC27]/40 flex items-center gap-3"
                  >
                    <motion.div
                      className="w-3 h-3 rounded-full bg-[#FBAC27]"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ delay: index * 0.4 + 0.2, duration: 0.3 }}
                    ></motion.div>
                    <div className="text-white text-sm">{record}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-r from-[#333F48] to-[#333F48] px-4 py-3 border-t border-white/10">
          <div className="text-white/50 text-xs text-center uppercase tracking-wider">
            Digital Trading Card • 2026 Edition
          </div>
        </div>
      </div>
    </div>
  );
}
