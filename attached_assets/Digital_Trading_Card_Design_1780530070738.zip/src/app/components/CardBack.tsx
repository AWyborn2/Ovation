import { Trophy, Award, Target } from 'lucide-react';
import clubLogo from '../../imports/HHCC_logo.png';

interface PlayerStats {
  matches: number;
  runs: number;
  battingAverage: number;
  strikeRate: number;
  centuries: number;
  halfCenturies: number;
  wickets: number;
  bowlingAverage: number;
  economy: number;
  maidens: number;
  fiveWickets: number;
}

interface PlayerData {
  name: string;
  number: number;
  country: string;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  rating: number;
  debutYear: number;
  stats: PlayerStats;
  additionalStats: {
    highestScore: number;
    bestBowling: string;
    catches: number;
    stumpings: number;
    runOuts: number;
  };
  achievements: {
    premierships: number[];
    awards: string[];
    records: string[];
  };
}

interface CardBackProps {
  player: PlayerData;
}

export function CardBack({ player }: CardBackProps) {
  const currentYear = 2026;
  const careerSpan = currentYear - player.debutYear;

  return (
    <div className="absolute w-full h-full backface-hidden rotate-y-180">
      <div className="relative bg-gradient-to-br from-[#333F48] to-[#41342B] rounded-3xl shadow-2xl overflow-hidden h-full">
        {/* Header */}
        <div className="relative h-16 bg-gradient-to-r from-[#333F48] to-[#333F48] border-b-4 border-[#FBAC27]">
          <div className="absolute right-0 top-0 w-24 h-24 bg-gradient-to-bl from-[#FBAC27] to-[#FBAC27] transform rotate-45 translate-x-8 -translate-y-8"></div>
          <div className="absolute right-4 top-3 z-10">
            <span className="text-white font-black text-3xl">{player.number}</span>
          </div>
          <div className="px-4 py-2 flex items-center gap-3">
            <img src={clubLogo} alt="Halls Head Cricket Club" className="w-10 h-10 object-contain" />
            <div>
              <div className="text-white/90 uppercase tracking-wider text-xs font-semibold">
                {player.name}
              </div>
              <div className="text-white/60 text-xs">
                Career Statistics
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="h-[calc(100%-4rem)] px-4 py-3 overflow-hidden">
          {/* Career Summary */}
          <div className="mb-2">
            <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider flex items-center gap-1">
              <Target className="w-3 h-3" />
              Career Summary
            </h3>
            <div className="grid grid-cols-3 gap-1.5">
              <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                <div className="text-white/60 text-[10px]">Debut</div>
                <div className="text-white font-bold text-xs">{player.debutYear}</div>
              </div>
              <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                <div className="text-white/60 text-[10px]">Years</div>
                <div className="text-white font-bold text-xs">{careerSpan}</div>
              </div>
              <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                <div className="text-white/60 text-[10px]">Matches</div>
                <div className="text-white font-bold text-xs">{player.stats.matches}</div>
              </div>
            </div>
          </div>

          {/* Complete Batting Stats */}
          {(player.role === 'Batsman' || player.role === 'All-Rounder' || player.role === 'Wicket-Keeper') && (
            <div className="mb-2">
              <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider">
                Batting Stats
              </h3>
              <div className="grid grid-cols-3 gap-1.5">
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Runs</div>
                  <div className="text-white font-black text-sm">{player.stats.runs.toLocaleString()}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Avg</div>
                  <div className="text-white font-black text-sm">{player.stats.battingAverage}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">S/R</div>
                  <div className="text-white font-black text-sm">{player.stats.strikeRate}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">High</div>
                  <div className="text-white font-black text-sm">{player.additionalStats.highestScore}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">100s</div>
                  <div className="text-white font-black text-sm">{player.stats.centuries}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">50s</div>
                  <div className="text-white font-black text-sm">{player.stats.halfCenturies}</div>
                </div>
              </div>
            </div>
          )}

          {/* Complete Bowling Stats */}
          {(player.role === 'Bowler' || player.role === 'All-Rounder') && (
            <div className="mb-2">
              <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider">
                Bowling Stats
              </h3>
              <div className="grid grid-cols-3 gap-1.5">
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Wkts</div>
                  <div className="text-white font-black text-sm">{player.stats.wickets}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Avg</div>
                  <div className="text-white font-black text-sm">{player.stats.bowlingAverage}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Econ</div>
                  <div className="text-white font-black text-sm">{player.stats.economy}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Best</div>
                  <div className="text-white font-black text-sm">{player.additionalStats.bestBowling}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">5W</div>
                  <div className="text-white font-black text-sm">{player.stats.fiveWickets}</div>
                </div>
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Mdns</div>
                  <div className="text-white font-black text-sm">{player.stats.maidens}</div>
                </div>
              </div>
            </div>
          )}

          {/* Fielding Stats */}
          <div className="mb-2">
            <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider">
              Fielding
            </h3>
            <div className="grid grid-cols-3 gap-1.5">
              <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                <div className="text-white/60 text-[10px] uppercase">Catches</div>
                <div className="text-white font-black text-sm">{player.additionalStats.catches}</div>
              </div>
              {player.role === 'Wicket-Keeper' && (
                <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                  <div className="text-white/60 text-[10px] uppercase">Stumpings</div>
                  <div className="text-white font-black text-sm">{player.additionalStats.stumpings}</div>
                </div>
              )}
              <div className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20">
                <div className="text-white/60 text-[10px] uppercase">Run Outs</div>
                <div className="text-white font-black text-sm">{player.additionalStats.runOuts}</div>
              </div>
            </div>
          </div>

          {/* Premierships */}
          {player.achievements.premierships.length > 0 && (
            <div className="mb-2">
              <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider flex items-center gap-1">
                <Trophy className="w-3 h-3" />
                Premierships ({player.achievements.premierships.length})
              </h3>
              <div className="bg-[#333F48]/80 rounded p-2 border border-[#FBAC27]/20">
                <div className="flex flex-wrap gap-1">
                  {player.achievements.premierships.map((year, index) => (
                    <div
                      key={index}
                      className="bg-[#FBAC27] text-[#333F48] px-2 py-0.5 rounded-full font-black text-xs"
                    >
                      {year}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Awards */}
          {player.achievements.awards.length > 0 && (
            <div className="mb-2">
              <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider flex items-center gap-1">
                <Award className="w-3 h-3" />
                Awards
              </h3>
              <div className="space-y-1">
                {player.achievements.awards.slice(0, 3).map((award, index) => (
                  <div
                    key={index}
                    className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20"
                  >
                    <div className="text-white text-[10px]">{award}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Records */}
          {player.achievements.records.length > 0 && (
            <div className="mb-2">
              <h3 className="text-[#FBAC27] text-xs uppercase font-bold mb-1 tracking-wider">
                Records
              </h3>
              <div className="space-y-1">
                {player.achievements.records.slice(0, 2).map((record, index) => (
                  <div
                    key={index}
                    className="bg-[#333F48]/80 rounded p-1.5 border border-[#FBAC27]/20 flex items-center gap-1.5"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-[#FBAC27] flex-shrink-0"></div>
                    <div className="text-white text-[10px]">{record}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="text-center py-2 border-t border-white/10 mt-2">
            <div className="text-white/50 text-[10px] uppercase tracking-wider">
              Digital Trading Card • 2026 Edition
            </div>
            <div className="text-[#FBAC27] text-[10px] mt-0.5">
              Tap to flip back
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
