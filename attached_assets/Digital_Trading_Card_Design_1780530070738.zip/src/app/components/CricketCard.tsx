import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Video, Download, Play, Repeat } from 'lucide-react';
import { CardFront } from './CardFront';
import { CardBack } from './CardBack';
import { AnimatedCard } from './AnimatedCard';

interface PlayerStats {
  matches: number;
  runs: number;
  battingAverage: number;
  strikeRate: number;
  centuries: number;
  halfCenturies: number;
  wickets: number;
  bowlingAverage: number;
  economy: number;
  maidens: number;
  fiveWickets: number;
}

interface PlayerData {
  name: string;
  number: number;
  country: string;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  rating: number;
  debutYear: number;
  stats: PlayerStats;
  additionalStats: {
    highestScore: number;
    bestBowling: string;
    catches: number;
    stumpings: number;
    runOuts: number;
  };
  achievements: {
    premierships: number[];
    awards: string[];
    records: string[];
  };
}

const samplePlayers: PlayerData[] = [
  {
    name: 'Virat Kohli',
    number: 18,
    country: 'India',
    role: 'Batsman',
    rating: 5,
    debutYear: 2008,
    stats: {
      matches: 274,
      runs: 13848,
      battingAverage: 58.18,
      strikeRate: 93.54,
      centuries: 50,
      halfCenturies: 72,
      wickets: 4,
      bowlingAverage: 52.50,
      economy: 6.35,
      maidens: 0,
      fiveWickets: 0,
    },
    additionalStats: {
      highestScore: 254,
      bestBowling: '1/15',
      catches: 132,
      stumpings: 0,
      runOuts: 8,
    },
    achievements: {
      premierships: [2018, 2021, 2023],
      awards: ['Club Champion 2021', 'Best Batsman 2023', 'Player of the Year 2022'],
      records: ['Most runs in a season', 'Fastest to 10,000 runs'],
    },
  },
  {
    name: 'Jasprit Bumrah',
    number: 93,
    country: 'India',
    role: 'Bowler',
    rating: 5,
    debutYear: 2016,
    stats: {
      matches: 143,
      runs: 89,
      battingAverage: 4.18,
      strikeRate: 52.35,
      centuries: 0,
      halfCenturies: 0,
      wickets: 362,
      bowlingAverage: 20.73,
      economy: 4.57,
      maidens: 38,
      fiveWickets: 12,
    },
    additionalStats: {
      highestScore: 16,
      bestBowling: '6/19',
      catches: 45,
      stumpings: 0,
      runOuts: 3,
    },
    achievements: {
      premierships: [2019, 2022],
      awards: ['Best Bowler 2019', 'Most Wickets 2022'],
      records: ['Best bowling figures', 'Most 5-wicket hauls'],
    },
  },
  {
    name: 'Ben Stokes',
    number: 55,
    country: 'England',
    role: 'All-Rounder',
    rating: 5,
    debutYear: 2011,
    stats: {
      matches: 215,
      runs: 6418,
      battingAverage: 35.89,
      strikeRate: 82.14,
      centuries: 13,
      halfCenturies: 31,
      wickets: 197,
      bowlingAverage: 32.64,
      economy: 5.52,
      maidens: 22,
      fiveWickets: 3,
    },
    additionalStats: {
      highestScore: 258,
      bestBowling: '6/22',
      catches: 123,
      stumpings: 0,
      runOuts: 15,
    },
    achievements: {
      premierships: [2017, 2020, 2021, 2024],
      awards: ['Club Champion 2020', 'All-Rounder of the Year 2021', 'MVP 2024'],
      records: ['Most all-round performances', 'Match-winning centuries'],
    },
  },
  {
    name: 'MS Dhoni',
    number: 7,
    country: 'India',
    role: 'Wicket-Keeper',
    rating: 5,
    debutYear: 2004,
    stats: {
      matches: 538,
      runs: 17266,
      battingAverage: 50.58,
      strikeRate: 87.56,
      centuries: 16,
      halfCenturies: 108,
      wickets: 1,
      bowlingAverage: 54.00,
      economy: 8.66,
      maidens: 0,
      fiveWickets: 0,
    },
    additionalStats: {
      highestScore: 183,
      bestBowling: '1/33',
      catches: 321,
      stumpings: 123,
      runOuts: 42,
    },
    achievements: {
      premierships: [2011, 2013, 2015, 2018, 2021],
      awards: ['Best Wicket-Keeper 2015', 'Captain of the Year 2018', 'Legend Award 2021'],
      records: ['Most dismissals', 'Most stumpings', 'Longest serving captain'],
    },
  },
];

type CardMode = 'static' | 'video';

export function CricketCard() {
  const [mode, setMode] = useState<CardMode>('static');
  const [isFlipped, setIsFlipped] = useState(false);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const player = samplePlayers[currentPlayerIndex];

  const handleFlip = () => {
    if (mode === 'static' && !isPlaying) {
      setIsFlipped(!isFlipped);
    }
  };

  const handleDownload = () => {
    alert('Card image download initiated!');
  };

  const handlePlayAnimation = () => {
    setIsPlaying(true);
  };

  const handleAnimationComplete = () => {
    setIsPlaying(false);
  };

  const startRecording = async () => {
    if (!cardRef.current) return;

    try {
      const stream = await (navigator.mediaDevices as any).getDisplayMedia({
        video: { mediaSource: 'screen' },
        audio: false,
      });

      // Try MP4 first, fallback to WebM
      let mimeType = 'video/webm;codecs=vp9';
      let extension = 'webm';

      if (MediaRecorder.isTypeSupported('video/mp4')) {
        mimeType = 'video/mp4';
        extension = 'mp4';
      } else if (MediaRecorder.isTypeSupported('video/webm;codecs=h264')) {
        mimeType = 'video/webm;codecs=h264';
        extension = 'mp4';
      } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
        mimeType = 'video/webm;codecs=vp9';
        extension = 'webm';
      } else if (MediaRecorder.isTypeSupported('video/webm')) {
        mimeType = 'video/webm';
        extension = 'webm';
      }

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: mimeType,
      });

      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${player.name.replace(/\s+/g, '-')}-trading-card.${extension}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        stream.getTracks().forEach((track) => track.stop());
        setIsRecording(false);
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Start animation
      setIsPlaying(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Please select the browser tab/window to record when prompted.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  return (
    <div className="relative w-full max-w-sm mx-auto">
      {/* Mode Selector */}
      <div className="mb-4 flex gap-2 justify-center">
        <button
          onClick={() => {
            setMode('static');
            setIsPlaying(false);
            setIsFlipped(false);
          }}
          className={`px-6 py-3 rounded-lg font-bold text-sm uppercase transition-all ${
            mode === 'static'
              ? 'bg-[#FBAC27] text-[#333F48]'
              : 'bg-[#333F48] text-white hover:bg-[#333F48]/80'
          }`}
          disabled={isRecording}
        >
          Static Card
        </button>
        <button
          onClick={() => {
            setMode('video');
            setIsFlipped(false);
          }}
          className={`px-6 py-3 rounded-lg font-bold text-sm uppercase transition-all ${
            mode === 'video'
              ? 'bg-[#FBAC27] text-[#333F48]'
              : 'bg-[#333F48] text-white hover:bg-[#333F48]/80'
          }`}
          disabled={isRecording}
        >
          Video Mode
        </button>
      </div>

      {/* Player Role Switcher */}
      <div className="mb-4 flex gap-2 justify-center flex-wrap">
        {samplePlayers.map((p, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrentPlayerIndex(index);
              setIsFlipped(false);
              setIsPlaying(false);
            }}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all ${
              currentPlayerIndex === index
                ? 'bg-[#FBAC27] text-[#333F48]'
                : 'bg-[#333F48] text-white hover:bg-[#333F48]/80'
            }`}
            disabled={isRecording || isPlaying}
          >
            {p.role}
          </button>
        ))}
      </div>

      {/* Video Mode Controls */}
      {mode === 'video' && (
        <div className="mb-4 flex gap-2 justify-center">
          {!isPlaying && !isRecording && (
            <button
              onClick={handlePlayAnimation}
              className="flex items-center gap-2 bg-[#FBAC27] hover:bg-[#FBAC27]/80 text-[#333F48] px-4 py-2 rounded-lg font-bold text-sm transition-all"
            >
              <Play className="w-4 h-4" />
              Preview Animation
            </button>
          )}
          {!isRecording && (
            <button
              onClick={startRecording}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-bold text-sm transition-all"
            >
              <Video className="w-4 h-4" />
              Record & Export
            </button>
          )}
          {isRecording && (
            <button
              onClick={stopRecording}
              className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg font-bold text-sm animate-pulse"
            >
              <Download className="w-4 h-4" />
              Stop & Download
            </button>
          )}
          {isPlaying && !isRecording && (
            <button
              onClick={() => setIsPlaying(false)}
              className="flex items-center gap-2 bg-[#333F48] text-white px-4 py-2 rounded-lg font-bold text-sm"
            >
              <Repeat className="w-4 h-4" />
              Reset
            </button>
          )}
        </div>
      )}

      {/* Card Container */}
      <div
        ref={cardRef}
        className={`relative w-full h-[800px] ${
          mode === 'static' ? 'perspective-1000 cursor-pointer' : ''
        }`}
        onClick={mode === 'static' && !isRecording && !isPlaying ? handleFlip : undefined}
      >
        {mode === 'static' ? (
          <motion.div
            className="relative w-full h-full preserve-3d"
            animate={{
              rotateY: isFlipped ? 180 : 0,
            }}
            transition={{
              duration: 0.8,
              ease: [0.23, 1, 0.32, 1],
            }}
          >
            <CardFront player={player} onDownload={handleDownload} />
            <CardBack player={player} />
          </motion.div>
        ) : (
          <AnimatedCard player={player} isPlaying={isPlaying} onComplete={handleAnimationComplete} />
        )}
      </div>

      {/* Instructions */}
      <div className="mt-4 text-center text-white/60 text-xs">
        {mode === 'static' ? (
          'Click card to flip between front and back'
        ) : (
          <>
            {isRecording ? (
              'Recording in progress - click "Stop & Download" when animation completes'
            ) : (
              'Preview the animation or record it for social media export (18 seconds)'
            )}
          </>
        )}
      </div>
    </div>
  );
}
