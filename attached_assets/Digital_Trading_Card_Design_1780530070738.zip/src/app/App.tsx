import { CricketCard } from './components/CricketCard';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-8">
      <CricketCard />
    </div>
  );
}