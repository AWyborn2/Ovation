
  # Digital Trading Card Design

  This is a code bundle for Digital Trading Card Design. The original project is available at https://www.figma.com/design/ElbzD3Gowah8dLHKaa7UtK/Digital-Trading-Card-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  