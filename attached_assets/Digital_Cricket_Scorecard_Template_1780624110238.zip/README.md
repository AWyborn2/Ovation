
  # Digital Cricket Scorecard Template

  This is a code bundle for Digital Cricket Scorecard Template. The original project is available at https://www.figma.com/design/7DlaAEKakZweqbd2b2tqgO/Digital-Cricket-Scorecard-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  