import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface ScorecardSettings {
  backgroundImage: string | null;
  bgOpacity: number;
  matchTitle: string;
  venue: string;
}

const STORAGE_KEY = "pca_scorecard_settings";

const defaults: ScorecardSettings = {
  backgroundImage: null,
  bgOpacity: 0.22,
  matchTitle: "Halls Head CC vs Mandurah CC",
  venue: "Falcon Reserve, Halls Head",
};

function load(): ScorecardSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaults;
    return { ...defaults, ...JSON.parse(raw) };
  } catch {
    return defaults;
  }
}

interface SettingsContextValue {
  settings: ScorecardSettings;
  update: (patch: Partial<ScorecardSettings>) => void;
  reset: () => void;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<ScorecardSettings>(load);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // storage quota exceeded — silently ignore
    }
  }, [settings]);

  function update(patch: Partial<ScorecardSettings>) {
    setSettings((prev) => ({ ...prev, ...patch }));
  }

  function reset() {
    setSettings(defaults);
    localStorage.removeItem(STORAGE_KEY);
  }

  return (
    <SettingsContext.Provider value={{ settings, update, reset }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used inside <SettingsProvider>");
  return ctx;
}
