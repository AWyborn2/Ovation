import { useState } from "react";
import { SettingsProvider, useSettings } from "./context/SettingsContext";
import { CricketScorecard } from "./components/cricket-scorecard/CricketScorecard";
import { PlayerStatsModal } from "./components/cricket-scorecard/PlayerStatsModal";
import { AdminSettings } from "./components/AdminSettings";
import {
  hallsHead1stInnings,
  mandurah1stInningsBowling,
  hallsHead2ndInnings,
  mandurah2ndInningsBowling,
} from "./components/cricket-scorecard/mockData";

const INNINGS = [
  { label: "1st Innings", batting: hallsHead1stInnings, bowling: mandurah1stInningsBowling },
  { label: "2nd Innings", batting: hallsHead2ndInnings, bowling: mandurah2ndInningsBowling },
];

type Page = "scorecard" | "admin";

function AppInner() {
  const { settings } = useSettings();
  const [page, setPage] = useState<Page>("scorecard");
  const [activeInnings, setActiveInnings] = useState(0);
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);

  const current = INNINGS[activeInnings];

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-start py-8 px-4"
      style={{ background: "#0d1117" }}
    >
      {/* ── Top nav ─────────────────────────────────────────────────────── */}
      <div className="w-full max-w-2xl mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p
              className="uppercase tracking-widest"
              style={{ color: "#f5a623", fontSize: 11, fontWeight: 800, letterSpacing: "0.2em" }}
            >
              Peel Cricket Association
            </p>
            <p style={{ color: "#4b5563", fontSize: 11 }}>A Grade Wyllie Cup — 2025/26 Season</p>
          </div>

          {/* Nav tabs */}
          <div
            className="flex rounded-lg overflow-hidden"
            style={{ border: "1px solid #30363d" }}
          >
            {(["scorecard", "admin"] as Page[]).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                style={{
                  background: page === p ? "#f5a623" : "#161b22",
                  color: page === p ? "#00305c" : "#8b949e",
                  fontWeight: 700,
                  fontSize: 12,
                  letterSpacing: "0.06em",
                  border: "none",
                  padding: "8px 16px",
                  cursor: "pointer",
                  borderRight: p === "scorecard" ? "1px solid #30363d" : "none",
                }}
              >
                {p === "scorecard" ? "Scorecard" : "⚙ Admin"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Page content ────────────────────────────────────────────────── */}
      <div className="w-full max-w-2xl">

        {page === "scorecard" && (
          <div className="flex flex-col gap-4">
            {/* Innings tabs */}
            <div
              className="flex rounded-lg overflow-hidden"
              style={{ border: "1px solid #30363d" }}
            >
              {INNINGS.map((inn, i) => (
                <button
                  key={i}
                  onClick={() => setActiveInnings(i)}
                  style={{
                    flex: 1,
                    padding: "12px 0",
                    background: activeInnings === i ? "#f5a623" : "#161b22",
                    color: activeInnings === i ? "#00305c" : "#8b949e",
                    fontWeight: 800,
                    fontSize: 13,
                    letterSpacing: "0.06em",
                    border: "none",
                    cursor: "pointer",
                    borderRight: i === 0 ? "1px solid #30363d" : "none",
                  }}
                >
                  {inn.label}
                </button>
              ))}
            </div>

            {/* Scorecard — reads background settings from context */}
            <CricketScorecard
              key={activeInnings}
              battingInnings={current.batting}
              bowlingInnings={current.bowling}
              onPlayerClick={(id) => setSelectedPlayerId(id)}
              matchTitle={settings.matchTitle}
              venue={settings.venue}
              backgroundImage={settings.backgroundImage}
              bgOpacity={settings.bgOpacity}
            />

            <p style={{ color: "#4b5563", fontSize: 11, textAlign: "center" }}>
              Tap any player name to view season stats · Background and match info set in{" "}
              <button
                onClick={() => setPage("admin")}
                style={{ color: "#f5a623", background: "none", border: "none", fontSize: 11, cursor: "pointer", padding: 0, fontWeight: 600 }}
              >
                Admin Settings
              </button>
            </p>
          </div>
        )}

        {page === "admin" && <AdminSettings />}
      </div>

      <PlayerStatsModal
        playerId={selectedPlayerId}
        onClose={() => setSelectedPlayerId(null)}
      />
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AppInner />
    </SettingsProvider>
  );
}
