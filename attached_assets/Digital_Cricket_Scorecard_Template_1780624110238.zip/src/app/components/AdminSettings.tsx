import { useRef } from "react";
import { useSettings } from "../context/SettingsContext";

export function AdminSettings() {
  const { settings, update, reset } = useSettings();
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => update({ backgroundImage: ev.target?.result as string });
    reader.readAsDataURL(file);
    e.target.value = "";
  }

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col gap-6">

      {/* Header */}
      <div>
        <p
          className="uppercase"
          style={{ color: "#f5a623", fontSize: 11, fontWeight: 800, letterSpacing: "0.18em" }}
        >
          Admin Settings
        </p>
        <p style={{ color: "#4b5563", fontSize: 11, marginTop: 3 }}>
          Changes apply to all scorecards and persist across sessions.
        </p>
      </div>

      {/* ── Match details ──────────────────────────────────────────────────── */}
      <Section title="Match Details">
        <Field label="Match Title">
          <input
            type="text"
            value={settings.matchTitle}
            onChange={(e) => update({ matchTitle: e.target.value })}
            placeholder="e.g. Halls Head CC vs Mandurah CC"
            style={inputStyle}
          />
        </Field>
        <Field label="Venue">
          <input
            type="text"
            value={settings.venue}
            onChange={(e) => update({ venue: e.target.value })}
            placeholder="e.g. Falcon Reserve, Halls Head"
            style={inputStyle}
          />
        </Field>
      </Section>

      {/* ── Scorecard background ───────────────────────────────────────────── */}
      <Section title="Scorecard Background Image">
        <p style={{ color: "#6b7280", fontSize: 11, marginBottom: 12 }}>
          This image will appear behind every scorecard. Upload a venue photo, team banner, or
          sponsor graphic. It is also embedded into exported PNG images.
        </p>

        {/* Current preview */}
        {settings.backgroundImage ? (
          <div
            className="rounded-lg overflow-hidden mb-4 relative"
            style={{
              height: 140,
              background: `url(${settings.backgroundImage}) center/cover`,
              border: "1px solid #30363d",
            }}
          >
            <div
              className="absolute inset-0 flex items-end p-3"
              style={{ background: "linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%)" }}
            >
              <span style={{ color: "#9ca3af", fontSize: 11 }}>Current background</span>
            </div>
          </div>
        ) : (
          <div
            className="rounded-lg flex items-center justify-center mb-4"
            style={{ height: 100, border: "2px dashed #30363d", background: "#161b22" }}
          >
            <span style={{ color: "#4b5563", fontSize: 12 }}>No background image set</span>
          </div>
        )}

        {/* Upload / remove buttons */}
        <div className="flex gap-3 flex-wrap">
          <button onClick={() => fileInputRef.current?.click()} style={btnPrimary}>
            {settings.backgroundImage ? "Replace image" : "Upload image"}
          </button>
          {settings.backgroundImage && (
            <button onClick={() => update({ backgroundImage: null })} style={btnDanger}>
              Remove image
            </button>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            style={{ display: "none" }}
          />
        </div>

        {/* Opacity */}
        {settings.backgroundImage && (
          <div className="mt-5">
            <div className="flex items-center justify-between mb-2">
              <span style={{ color: "#8b949e", fontSize: 12, fontWeight: 600 }}>Image opacity</span>
              <span
                className="rounded px-2 py-[2px]"
                style={{ background: "#21262d", color: "#f5a623", fontSize: 12, fontWeight: 700 }}
              >
                {Math.round(settings.bgOpacity * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={settings.bgOpacity}
              onChange={(e) => update({ bgOpacity: Number(e.target.value) })}
              className="w-full"
              style={{ accentColor: "#f5a623" }}
            />
            <div className="flex justify-between mt-1">
              <span style={{ color: "#4b5563", fontSize: 10 }}>Subtle</span>
              <span style={{ color: "#4b5563", fontSize: 10 }}>Vivid</span>
            </div>
          </div>
        )}
      </Section>

      {/* ── Danger zone ────────────────────────────────────────────────────── */}
      <Section title="Reset">
        <p style={{ color: "#6b7280", fontSize: 11, marginBottom: 12 }}>
          Restore all admin settings to their defaults and clear stored data.
        </p>
        <button onClick={reset} style={btnDanger}>
          Reset all settings
        </button>
      </Section>

    </div>
  );
}

// ── Small layout helpers ──────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div
      className="rounded-lg p-5 flex flex-col gap-3"
      style={{ background: "#161b22", border: "1px solid #30363d" }}
    >
      <p
        className="uppercase"
        style={{ color: "#8b949e", fontSize: 10, fontWeight: 700, letterSpacing: "0.12em", marginBottom: 4 }}
      >
        {title}
      </p>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label style={{ color: "#c9d1d9", fontSize: 12, fontWeight: 600 }}>{label}</label>
      {children}
    </div>
  );
}

// ── Shared style tokens ───────────────────────────────────────────────────────

const inputStyle: React.CSSProperties = {
  background: "#0d1117",
  border: "1px solid #30363d",
  borderRadius: 6,
  color: "#c9d1d9",
  fontSize: 13,
  padding: "8px 12px",
  outline: "none",
  width: "100%",
};

const btnPrimary: React.CSSProperties = {
  background: "#21262d",
  color: "#c9d1d9",
  border: "1px solid #30363d",
  borderRadius: 6,
  fontWeight: 600,
  fontSize: 12,
  padding: "8px 16px",
  cursor: "pointer",
};

const btnDanger: React.CSSProperties = {
  background: "transparent",
  color: "#f85149",
  border: "1px solid #f85149",
  borderRadius: 6,
  fontWeight: 600,
  fontSize: 12,
  padding: "8px 16px",
  cursor: "pointer",
};
