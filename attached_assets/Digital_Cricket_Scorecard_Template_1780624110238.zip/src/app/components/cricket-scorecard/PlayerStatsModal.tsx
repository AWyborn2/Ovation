import { mockPlayerStats } from "./mockData";

interface PlayerStatsModalProps {
  playerId: string | null;
  onClose: () => void;
}

export function PlayerStatsModal({ playerId, onClose }: PlayerStatsModalProps) {
  if (!playerId) return null;
  const stats = mockPlayerStats[playerId];
  if (!stats) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.75)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-lg overflow-hidden shadow-2xl"
        style={{ background: "#1a1a2e", border: "1px solid rgba(255,255,255,0.12)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal header */}
        <div
          className="flex items-center justify-between px-5 py-4"
          style={{ background: "#111827", borderBottom: "1px solid rgba(255,255,255,0.08)" }}
        >
          <div>
            <p
              className="uppercase"
              style={{ color: "#f5c518", fontSize: 18, fontWeight: 800, letterSpacing: "0.08em" }}
            >
              {stats.name}
            </p>
            <p style={{ color: "#9ca3af", fontSize: 12, marginTop: 2 }}>{stats.role}</p>
          </div>
          <button
            onClick={onClose}
            style={{
              color: "#9ca3af",
              background: "none",
              border: "none",
              fontSize: 22,
              cursor: "pointer",
              lineHeight: 1,
            }}
          >
            ×
          </button>
        </div>

        {/* Stats grid */}
        <div className="p-5">
          <p
            className="uppercase mb-3"
            style={{ color: "#6b7280", fontSize: 10, fontWeight: 700, letterSpacing: "0.1em" }}
          >
            Test Career • {stats.matches} Matches
          </p>

          {/* Batting stats */}
          {stats.runs !== undefined && (
            <>
              <p
                className="uppercase mb-2"
                style={{ color: "#4b5563", fontSize: 9, fontWeight: 700, letterSpacing: "0.1em" }}
              >
                Batting
              </p>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {[
                  { label: "Runs", value: stats.runs?.toLocaleString() },
                  { label: "Average", value: stats.average?.toFixed(1) },
                  { label: "Strike Rate", value: stats.strikeRate?.toFixed(1) },
                  { label: "100s", value: stats.hundreds },
                  { label: "50s", value: stats.fifties },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="rounded p-2 text-center"
                    style={{ background: "rgba(255,255,255,0.04)" }}
                  >
                    <p style={{ color: "#e5e7eb", fontSize: 18, fontWeight: 800 }}>{s.value ?? "—"}</p>
                    <p style={{ color: "#6b7280", fontSize: 9, fontWeight: 600, letterSpacing: "0.06em" }}>
                      {s.label.toUpperCase()}
                    </p>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Bowling stats */}
          {stats.wickets !== undefined && (
            <>
              <p
                className="uppercase mb-2"
                style={{ color: "#4b5563", fontSize: 9, fontWeight: 700, letterSpacing: "0.1em" }}
              >
                Bowling
              </p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Wickets", value: stats.wickets },
                  { label: "Average", value: stats.bowlingAvg?.toFixed(1) },
                  { label: "Economy", value: stats.economy?.toFixed(2) },
                  { label: "5 Wickets", value: stats.fiveWickets },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="rounded p-2 text-center"
                    style={{ background: "rgba(255,255,255,0.04)" }}
                  >
                    <p style={{ color: "#e5e7eb", fontSize: 18, fontWeight: 800 }}>{s.value ?? "—"}</p>
                    <p style={{ color: "#6b7280", fontSize: 9, fontWeight: 600, letterSpacing: "0.06em" }}>
                      {s.label.toUpperCase()}
                    </p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <div
          className="px-5 py-3 text-center"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          <p style={{ color: "#4b5563", fontSize: 10 }}>Player ID: {playerId}</p>
        </div>
      </div>
    </div>
  );
}
