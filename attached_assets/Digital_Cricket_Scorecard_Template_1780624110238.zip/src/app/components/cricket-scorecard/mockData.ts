import { InningsData, TeamColors } from "./types";

// ─── Halls Head Cricket Club colours ────────────────────────────────────────
const hallsHeadColors: TeamColors = {
  primary: "#00305c",          // navy blue
  secondary: "#f5a623",        // gold
  text: "#f5a623",
  accentText: "#00305c",
  rowOdd: "#002845",
  rowEven: "#001f38",
  rowText: "#e8e8e8",
  totalBg: "#00305c",
  totalText: "#f5a623",
  borderColor: "rgba(245,166,35,0.14)",
};

// ─── Mandurah CC (opposition) colours ────────────────────────────────────────
const mandurahColors: TeamColors = {
  primary: "#1a1a1a",
  secondary: "#c0392b",
  text: "#f0f0f0",
  accentText: "#f0f0f0",
  rowOdd: "#1e1e1e",
  rowEven: "#161616",
  rowText: "#e0e0e0",
  totalBg: "#111",
  totalText: "#f0f0f0",
  borderColor: "rgba(192,57,43,0.15)",
};

// ─── 1st Innings — Halls Head batting ────────────────────────────────────────
export const hallsHead1stInnings: InningsData = {
  teamName: "Halls Head",
  teamShortName: "HHCC",
  inningsLabel: "1ST INNINGS",
  teamColors: hallsHeadColors,
  // logoUrl: "/logos/halls-head.png",
  batsmen: [
    { player_id: "hh-manuel",  name: "Manuel",  dismissalType: "c", catcher: "Smith",    catcher_id: "man-001", bowler: "Jones",    bowler_id: "man-jones",   runs: 67,  balls: 89 },
    { player_id: "hh-caine-t", name: "Caine T", dismissalType: "b",                                             bowler: "Williams", bowler_id: "man-williams", runs: 23,  balls: 45 },
    { player_id: "hh-rudge",   name: "Rudge",   dismissalType: "c", catcher: "Green",    catcher_id: "man-002", bowler: "Patel",    bowler_id: "man-patel",   runs: 12,  balls: 28 },
    { player_id: "hh-miles",   name: "Miles",   dismissalType: "run out", catcher: "Thompson", catcher_id: "man-003",                                         runs: 44,  balls: 52 },
    { player_id: "hh-barnes",  name: "Barnes",  dismissalType: "c", catcher: "Green",    catcher_id: "man-002", bowler: "Jones",    bowler_id: "man-jones",   runs: 8,   balls: 19 },
    { player_id: "hh-wyllie",  name: "Wyllie",  dismissalType: "b",                                             bowler: "Williams", bowler_id: "man-williams", runs: 15,  balls: 31 },
    { player_id: "hh-little",  name: "Little",  dismissalType: "lbw",                                           bowler: "Patel",    bowler_id: "man-patel",   runs: 5,   balls: 11 },
    { player_id: "hh-higton-b",name: "Higton B",dismissalType: "not out",                                                                                     runs: 34,  balls: 67 },
    { player_id: "hh-doyle",   name: "Doyle",   dismissalType: "b",                                             bowler: "Thomas",   bowler_id: "man-thomas",  runs: 7,   balls: 14 },
    { player_id: "hh-felton",  name: "Felton",  dismissalType: "c",                                             bowler: "Thomas",   bowler_id: "man-thomas",  runs: 2,   balls: 6  },
    { player_id: "hh-demmery", name: "Demmery", dismissalType: "b",                                             bowler: "Williams", bowler_id: "man-williams", runs: 0,   balls: 3  },
  ],
  extras: { total: 12, byes: 4, legByes: 5, wides: 3 },
  total: 229,
  wickets: 10,
  overs: 62.3,
  bowlers: [],
  fallOfWickets: [],
};

// ─── 1st Innings — Mandurah bowling ──────────────────────────────────────────
export const mandurah1stInningsBowling: InningsData = {
  teamName: "Mandurah CC",
  teamShortName: "MCC",
  inningsLabel: "1ST INNINGS",
  teamColors: mandurahColors,
  batsmen: [],
  extras: { total: 12, byes: 4, legByes: 5, wides: 3 },
  total: 229,
  wickets: 10,
  overs: 62.3,
  bowlers: [
    { player_id: "man-jones",    name: "Jones",    overs: 15,   maidens: 3, runs: 54, wickets: 3, economy: 3.60 },
    { player_id: "man-williams", name: "Williams", overs: 14,   maidens: 4, runs: 47, wickets: 3, economy: 3.36 },
    { player_id: "man-patel",    name: "Patel",    overs: 12,   maidens: 2, runs: 58, wickets: 2, economy: 4.83 },
    { player_id: "man-thomas",   name: "Thomas",   overs: 10.3, maidens: 1, runs: 58, wickets: 2, economy: 5.52 },
    { player_id: "man-001",      name: "Smith",    overs: 11,   maidens: 1, runs: 0,  wickets: 0, economy: 0.00 },
  ],
  fallOfWickets: [
    { wicket: 1, runs: 42 },
    { wicket: 2, runs: 71 },
    { wicket: 3, runs: 98 },
    { wicket: 4, runs: 113 },
    { wicket: 5, runs: 137 },
    { wicket: 6, runs: 160 },
    { wicket: 7, runs: 196 },
    { wicket: 8, runs: 212 },
    { wicket: 9, runs: 229 },
    { wicket: 10, runs: 229 },
  ],
};

// ─── 2nd Innings — Halls Head batting ────────────────────────────────────────
export const hallsHead2ndInnings: InningsData = {
  teamName: "Halls Head",
  teamShortName: "HHCC",
  inningsLabel: "2ND INNINGS",
  teamColors: hallsHeadColors,
  batsmen: [
    { player_id: "hh-manuel",  name: "Manuel",  dismissalType: "not out",                                                                                     runs: 108, balls: 143 },
    { player_id: "hh-caine-t", name: "Caine T", dismissalType: "c", catcher: "Brown",    catcher_id: "man-004", bowler: "Jones",    bowler_id: "man-jones",   runs: 18,  balls: 32 },
    { player_id: "hh-rudge",   name: "Rudge",   dismissalType: "b",                                             bowler: "Williams", bowler_id: "man-williams", runs: 5,   balls: 15 },
    { player_id: "hh-miles",   name: "Miles",   dismissalType: "c",                                             bowler: "Patel",    bowler_id: "man-patel",   runs: 31,  balls: 44 },
    { player_id: "hh-barnes",  name: "Barnes",  dismissalType: "b",                                             bowler: "Thomas",   bowler_id: "man-thomas",  runs: 0,   balls: 2  },
    { player_id: "hh-wyllie",  name: "Wyllie",  dismissalType: "c", catcher: "Thompson", catcher_id: "man-003", bowler: "Williams", bowler_id: "man-williams", runs: 22,  balls: 38 },
    { player_id: "hh-little",  name: "Little",  dismissalType: "not out",                                                                                     runs: 19,  balls: 27 },
    { player_id: "hh-higton-b",name: "Higton B",dnb: true, runs: 0, balls: 0 },
    { player_id: "hh-doyle",   name: "Doyle",   dnb: true, runs: 0, balls: 0 },
    { player_id: "hh-felton",  name: "Felton",  dnb: true, runs: 0, balls: 0 },
    { player_id: "hh-demmery", name: "Demmery", dnb: true, runs: 0, balls: 0 },
  ],
  extras: { total: 8, byes: 2, legByes: 3, wides: 3 },
  total: 211,
  wickets: 5,
  overs: 60,
  bowlers: [],
  fallOfWickets: [],
};

// ─── 2nd Innings — Mandurah bowling ──────────────────────────────────────────
export const mandurah2ndInningsBowling: InningsData = {
  teamName: "Mandurah CC",
  teamShortName: "MCC",
  inningsLabel: "2ND INNINGS",
  teamColors: mandurahColors,
  batsmen: [],
  extras: { total: 8, byes: 2, legByes: 3, wides: 3 },
  total: 211,
  wickets: 5,
  overs: 60,
  bowlers: [
    { player_id: "man-jones",    name: "Jones",    overs: 18, maidens: 4, runs: 72, wickets: 1, economy: 4.00 },
    { player_id: "man-williams", name: "Williams", overs: 16, maidens: 3, runs: 61, wickets: 2, economy: 3.81 },
    { player_id: "man-patel",    name: "Patel",    overs: 15, maidens: 2, runs: 47, wickets: 1, economy: 3.13 },
    { player_id: "man-thomas",   name: "Thomas",   overs: 11, maidens: 2, runs: 31, wickets: 1, economy: 2.82 },
  ],
  fallOfWickets: [
    { wicket: 1, runs: 28 },
    { wicket: 2, runs: 42 },
    { wicket: 3, runs: 85 },
    { wicket: 4, runs: 86 },
    { wicket: 5, runs: 152 },
  ],
};

export const mockPlayerStats: Record<string, {
  name: string;
  role: string;
  matches: number;
  runs?: number;
  average?: number;
  strikeRate?: number;
  hundreds?: number;
  fifties?: number;
  wickets?: number;
  bowlingAvg?: number;
  economy?: number;
  fiveWickets?: number;
}> = {
  "hh-manuel":   { name: "Jack Manuel",      role: "Batsman",             matches: 20, runs: 790,  average: 52.67, strikeRate: 93.71, hundreds: 2, fifties: 5 },
  "hh-miles":    { name: "Timothy Miles",    role: "All-rounder",         matches: 21, runs: 528,  average: 44.00, strikeRate: 110.69, hundreds: 0, fifties: 5, wickets: 26, bowlingAvg: 15.42, economy: 3.23, fiveWickets: 2 },
  "hh-rudge":    { name: "Josh Rudge",       role: "Batsman",             matches: 19, runs: 286,  average: 22.00, strikeRate: 58.13, hundreds: 0, fifties: 1 },
  "hh-wyllie":   { name: "Jake Wyllie",      role: "All-rounder",         matches: 20, runs: 264,  average: 17.60, strikeRate: 63.92, hundreds: 0, fifties: 0, wickets: 17, bowlingAvg: 19.35, economy: 4.23 },
  "hh-higton-b": { name: "Ben Higton",       role: "Bowler",              matches: 21, runs: 238,  average: 29.75, strikeRate: 56.26, wickets: 25, bowlingAvg: 16.72, economy: 2.69 },
  "hh-little":   { name: "Jarod Little",     role: "Wicketkeeper / Batter",matches: 21, runs: 154, average: 9.63, strikeRate: 41.40 },
  "hh-caine-t":  { name: "Travis Caine",     role: "Batsman",             matches: 18, runs: 152,  average: 16.89, strikeRate: 50.50, hundreds: 0, fifties: 1 },
  "hh-barnes":   { name: "Jacob Barnes",     role: "Batsman",             matches: 14, runs: 149,  average: 18.63, strikeRate: 56.87 },
  "hh-doyle":    { name: "Luca Doyle",       role: "All-rounder",         matches: 16, runs: 73,   average: 14.60, strikeRate: 52.52, wickets: 24, bowlingAvg: 12.79, economy: 2.59 },
  "hh-felton":   { name: "Mitchell Felton",  role: "Bowler",              matches: 20, runs: 41,   average: 6.83,  strikeRate: 51.90, wickets: 26, bowlingAvg: 17.38, economy: 3.58 },
  "hh-demmery":  { name: "Jett Demmery",     role: "Bowler",              matches: 20, runs: 18,   average: 3.60,  strikeRate: 51.43, wickets: 15, bowlingAvg: 33.47, economy: 4.33 },
  "man-jones":   { name: "A. Jones",         role: "Bowler",              matches: 12, wickets: 18, bowlingAvg: 24.3, economy: 3.8 },
  "man-williams":{ name: "B. Williams",      role: "Bowler",              matches: 12, wickets: 22, bowlingAvg: 21.5, economy: 3.2 },
  "man-patel":   { name: "C. Patel",         role: "Bowler",              matches: 11, wickets: 14, bowlingAvg: 28.1, economy: 4.1 },
  "man-thomas":  { name: "D. Thomas",        role: "Bowler",              matches: 10, wickets: 12, bowlingAvg: 31.0, economy: 4.5 },
};
