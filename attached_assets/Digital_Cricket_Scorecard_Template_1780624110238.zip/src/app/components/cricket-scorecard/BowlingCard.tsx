import { InningsData } from "./types";
import { TeamLogo } from "./TeamLogo";

interface BowlingCardProps {
  innings: InningsData;
  isExportMode?: boolean;
  onPlayerClick?: (playerId: string, playerName: string) => void;
}

export function BowlingCard({ innings, isExportMode, onPlayerClick }: BowlingCardProps) {
  const { teamColors: c } = innings;

  const extras = innings.extras;
  const extrasParts: string[] = [];
  if (extras.byes) extrasParts.push(`${extras.byes}B`);
  if (extras.legByes) extrasParts.push(`${extras.legByes}LB`);
  if (extras.wides) extrasParts.push(`${extras.wides}W`);
  if (extras.noBalls) extrasParts.push(`${extras.noBalls}NB`);

  return (
    <div
      className="w-full overflow-hidden rounded-sm shadow-lg"
      style={{ fontFamily: "'Arial Narrow', Arial, sans-serif" }}
    >
      {/* Header */}
      <div
        className="flex items-stretch"
        style={{ background: c.primary, borderBottom: `3px solid ${c.secondary}` }}
      >
        {/* Logo section */}
        <div
          className="flex items-center justify-center"
          style={{
            width: 72,
            minWidth: 72,
            background: `linear-gradient(135deg, ${c.primary} 0%, rgba(0,0,0,0.35) 100%)`,
            borderRight: `1px solid ${c.borderColor}`,
            padding: "10px 8px",
          }}
        >
          <TeamLogo
            logoUrl={innings.logoUrl}
            teamName={innings.teamName}
            primaryColor={c.primary}
            secondaryColor={c.secondary}
            size={52}
          />
        </div>

        {/* Team name */}
        <div className="flex flex-1 items-center justify-center py-3 px-4">
          <div className="text-center">
            <span
              className="tracking-widest uppercase block"
              style={{
                color: c.text,
                fontSize: "clamp(18px, 3.5vw, 28px)",
                fontWeight: 800,
                letterSpacing: "0.14em",
              }}
            >
              {innings.teamName}
            </span>
            {innings.teamShortName && (
              <span
                className="block"
                style={{ color: c.text, fontSize: 10, opacity: 0.5, letterSpacing: "0.1em" }}
              >
                {innings.teamShortName}
              </span>
            )}
          </div>
        </div>

        {/* Innings badge */}
        <div
          className="flex items-center justify-center px-3 py-2"
          style={{ background: c.secondary, minWidth: 80 }}
        >
          <div className="text-center" style={{ color: c.accentText }}>
            <div style={{ fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700, letterSpacing: "0.08em", lineHeight: 1.1 }}>
              {innings.inningsLabel.split(" ")[0]}
            </div>
            <div style={{ fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700, letterSpacing: "0.08em", lineHeight: 1.1 }}>
              {innings.inningsLabel.split(" ").slice(1).join(" ")}
            </div>
          </div>
        </div>
      </div>

      {/* Column headers */}
      <div
        className="grid"
        style={{
          gridTemplateColumns: "3fr 56px 64px 56px 72px 56px",
          background: c.primary,
          borderBottom: `1px solid ${c.borderColor}`,
          opacity: 0.85,
        }}
      >
        {["BOWLER", "OVERS", "MAIDENS", "RUNS", "WICKETS", "ECON"].map((h, i) => (
          <div
            key={i}
            className="py-1 px-2"
            style={{
              color: c.text,
              fontSize: "clamp(7px, 1.1vw, 10px)",
              fontWeight: 700,
              textAlign: i === 0 ? "left" : "center",
              letterSpacing: "0.05em",
              opacity: 0.8,
            }}
          >
            {h}
          </div>
        ))}
      </div>

      {/* Bowler rows */}
      {innings.bowlers.map((row, idx) => {
        const isOdd = idx % 2 === 0;
        const rowBg = isOdd ? c.rowOdd : c.rowEven;

        return (
          <div
            key={row.player_id}
            className="grid items-center"
            style={{
              gridTemplateColumns: "3fr 56px 64px 56px 72px 56px",
              background: rowBg,
              borderBottom: `1px solid ${c.borderColor}`,
            }}
          >
            {/* Bowler name */}
            <div className="px-2 py-[5px]">
              {!isExportMode && onPlayerClick ? (
                <button
                  onClick={() => onPlayerClick(row.player_id, row.name)}
                  className="text-left uppercase hover:underline focus:outline-none transition-opacity hover:opacity-80"
                  style={{
                    color: c.rowText,
                    fontSize: "clamp(10px, 1.8vw, 14px)",
                    fontWeight: 700,
                    letterSpacing: "0.04em",
                    background: "none",
                    border: "none",
                    padding: 0,
                    cursor: "pointer",
                  }}
                >
                  {row.name}
                </button>
              ) : (
                <span
                  className="uppercase"
                  style={{
                    color: c.rowText,
                    fontSize: "clamp(10px, 1.8vw, 14px)",
                    fontWeight: 700,
                    letterSpacing: "0.04em",
                  }}
                >
                  {row.name}
                </span>
              )}
            </div>

            {[row.overs, row.maidens, row.runs, row.wickets, row.economy.toFixed(2)].map(
              (val, i) => (
                <div
                  key={i}
                  className="text-center py-[5px]"
                  style={{
                    color: c.rowText,
                    fontSize: i === 3 ? "clamp(11px, 2vw, 15px)" : "clamp(10px, 1.7vw, 13px)",
                    fontWeight: i === 3 ? 800 : 400,
                    opacity: i === 3 ? 1 : 0.85,
                  }}
                >
                  {val}
                </div>
              )
            )}
          </div>
        );
      })}

      {/* Bottom section: Extras + FOW + Overs + Total */}
      <div style={{ background: c.totalBg, borderTop: `2px solid ${c.secondary}` }}>
        {/* Extras + FOW row */}
        <div
          className="flex items-start gap-4 px-2 py-[5px]"
          style={{ borderBottom: `1px solid ${c.borderColor}` }}
        >
          <div style={{ color: c.totalText, minWidth: 80 }}>
            <div style={{ fontSize: "clamp(9px, 1.4vw, 12px)", fontWeight: 700 }}>
              EXTRAS {innings.extras.total}
            </div>
            {extrasParts.length > 0 && (
              <div style={{ fontSize: "clamp(7px, 1.1vw, 10px)", opacity: 0.7 }}>
                {extrasParts.join(" ")}
              </div>
            )}
          </div>

          {innings.fallOfWickets.length > 0 && (
            <div className="flex-1">
              <div style={{ color: c.totalText, fontSize: "clamp(8px, 1.2vw, 11px)", fontWeight: 700, marginBottom: 2 }}>
                FOW
                {innings.fallOfWickets.map((fow) => (
                  <span key={fow.wicket} style={{ marginLeft: 6, fontWeight: 400 }}>
                    {fow.wicket} {fow.runs}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Overs + Total */}
        <div className="flex items-center justify-between px-2 py-[6px]">
          <div style={{ color: c.totalText, fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700 }}>
            OVERS {innings.overs}
          </div>
          <div
            style={{
              color: c.totalText,
              fontSize: "clamp(16px, 3vw, 24px)",
              fontWeight: 900,
              letterSpacing: "0.02em",
            }}
          >
            {innings.total}
          </div>
        </div>
      </div>
    </div>
  );
}
