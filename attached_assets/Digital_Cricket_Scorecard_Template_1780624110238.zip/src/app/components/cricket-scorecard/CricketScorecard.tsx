import { useRef, useState } from "react";
import { toPng } from "html-to-image";
import { BattingCard } from "./BattingCard";
import { BowlingCard } from "./BowlingCard";
import { InningsData } from "./types";

interface CricketScorecardProps {
  battingInnings: InningsData;
  bowlingInnings: InningsData;
  onPlayerClick?: (playerId: string, playerName: string) => void;
  matchTitle?: string;
  venue?: string;
  backgroundImage?: string | null;   // data URL or external URL
  bgOpacity?: number;                // 0–1, default 0.22
}

export function CricketScorecard({
  battingInnings,
  bowlingInnings,
  onPlayerClick,
  matchTitle,
  venue,
  backgroundImage,
  bgOpacity = 0.22,
}: CricketScorecardProps) {
  const exportRef = useRef<HTMLDivElement>(null);
  const [exporting, setExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  async function handleExport() {
    if (!exportRef.current) return;
    setExporting(true);
    setExportSuccess(false);
    try {
      const dataUrl = await toPng(exportRef.current, {
        cacheBust: true,
        pixelRatio: 2,
        backgroundColor: "#111827",
      });
      const link = document.createElement("a");
      link.download = `scorecard-${battingInnings.teamName.toLowerCase().replace(/\s+/g, "-")}-${battingInnings.inningsLabel.replace(/\s+/g, "-").toLowerCase()}.png`;
      link.href = dataUrl;
      link.click();
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (e) {
      console.error("Export failed:", e);
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="w-full">
      {/* Export button row */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div>
          {matchTitle && (
            <p className="uppercase" style={{ color: "#e5e7eb", fontSize: "clamp(11px,1.8vw,14px)", fontWeight: 700, letterSpacing: "0.08em" }}>
              {matchTitle}
            </p>
          )}
          {venue && (
            <p style={{ color: "#9ca3af", fontSize: "clamp(9px,1.3vw,11px)" }}>{venue}</p>
          )}
        </div>
        <button
          onClick={handleExport}
          disabled={exporting}
          className="flex items-center gap-2 px-4 py-2 rounded transition-all disabled:opacity-50"
          style={{ background: "#1d4ed8", color: "#fff", fontSize: "clamp(10px,1.5vw,13px)", fontWeight: 700, letterSpacing: "0.04em", border: "none", cursor: exporting ? "wait" : "pointer" }}
        >
          {exportSuccess ? "✓ Saved!" : exporting ? "Exporting…" : "⬇ Export Image"}
        </button>
      </div>

      {/* Exportable region */}
      <div
        ref={exportRef}
        className="relative flex flex-col gap-3 p-3 rounded overflow-hidden"
        style={{ background: "#111827" }}
      >
        {/* Background image layer */}
        {backgroundImage && (
          <div
            aria-hidden
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage: `url(${backgroundImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              opacity: bgOpacity,
              pointerEvents: "none",
              zIndex: 0,
            }}
          />
        )}

        {/* Content sits above background */}
        <div className="relative" style={{ zIndex: 1 }}>
          {(matchTitle || venue) && (
            <div className="text-center pb-2 mb-1" style={{ borderBottom: "1px solid #374151" }}>
              {matchTitle && (
                <p className="uppercase" style={{ color: "#d1d5db", fontSize: 13, fontWeight: 700, letterSpacing: "0.1em" }}>
                  {matchTitle}
                </p>
              )}
              {venue && <p style={{ color: "#6b7280", fontSize: 11 }}>{venue}</p>}
            </div>
          )}

          <div className="flex flex-col gap-3">
            <BattingCard innings={battingInnings} onPlayerClick={onPlayerClick} />
            <BowlingCard innings={bowlingInnings} onPlayerClick={onPlayerClick} />
          </div>
        </div>
      </div>
    </div>
  );
}
