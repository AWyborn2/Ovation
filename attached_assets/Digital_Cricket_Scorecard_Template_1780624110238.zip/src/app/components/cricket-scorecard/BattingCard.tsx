import { InningsData, BatsmanRow } from "./types";
import { TeamLogo } from "./TeamLogo";

interface BattingCardProps {
  innings: InningsData;
  isExportMode?: boolean;
  onPlayerClick?: (playerId: string, playerName: string) => void;
}

function getDismissalText(row: BatsmanRow): { left: string; right: string } {
  if (row.dnb) return { left: "did not bat", right: "" };
  const type = row.dismissalType;
  if (!type || type === "not out") return { left: "not out", right: "" };
  if (type === "run out") return { left: "run out", right: `(${row.catcher ?? ""})` };
  if (type === "b") return { left: "", right: `b ${row.bowler ?? ""}` };
  if (type === "lbw") return { left: "lbw", right: `b ${row.bowler ?? ""}` };
  if (type === "hit wicket") return { left: "hit wicket", right: `b ${row.bowler ?? ""}` };
  if (type === "ret hurt") return { left: "ret hurt", right: "" };
  if (type === "c") {
    const cText = row.catcher ? `c ${row.catcher}` : "c & b";
    return { left: cText, right: `b ${row.bowler ?? ""}` };
  }
  return { left: type, right: "" };
}

export function BattingCard({ innings, isExportMode, onPlayerClick }: BattingCardProps) {
  const { teamColors: c } = innings;

  const batsmen = innings.batsmen.filter((b) => !b.dnb);
  const dnb = innings.batsmen.filter((b) => b.dnb);

  const extras = innings.extras;
  const extrasParts: string[] = [];
  if (extras.byes) extrasParts.push(`${extras.byes}B`);
  if (extras.legByes) extrasParts.push(`${extras.legByes}LB`);
  if (extras.wides) extrasParts.push(`${extras.wides}W`);
  if (extras.noBalls) extrasParts.push(`${extras.noBalls}NB`);
  if (extras.penaltyRuns) extrasParts.push(`${extras.penaltyRuns}P`);

  return (
    <div
      className="w-full overflow-hidden rounded-sm shadow-lg"
      style={{ fontFamily: "'Arial Narrow', Arial, sans-serif" }}
    >
      {/* Header */}
      <div
        className="flex items-stretch"
        style={{ background: c.primary, borderBottom: `3px solid ${c.secondary}` }}
      >
        {/* Logo section */}
        <div
          className="flex items-center justify-center"
          style={{
            width: 72,
            minWidth: 72,
            background: `linear-gradient(135deg, ${c.primary} 0%, rgba(0,0,0,0.35) 100%)`,
            borderRight: `1px solid ${c.borderColor}`,
            padding: "10px 8px",
          }}
        >
          <TeamLogo
            logoUrl={innings.logoUrl}
            teamName={innings.teamName}
            primaryColor={c.primary}
            secondaryColor={c.secondary}
            size={52}
          />
        </div>

        {/* Team name */}
        <div className="flex flex-1 items-center justify-center py-3 px-4">
          <div className="text-center">
            <span
              className="tracking-widest uppercase block"
              style={{
                color: c.text,
                fontSize: "clamp(18px, 3.5vw, 28px)",
                fontWeight: 800,
                letterSpacing: "0.14em",
              }}
            >
              {innings.teamName}
            </span>
            {innings.teamShortName && (
              <span
                className="block"
                style={{ color: c.text, fontSize: 10, opacity: 0.5, letterSpacing: "0.1em" }}
              >
                {innings.teamShortName}
              </span>
            )}
          </div>
        </div>

        {/* Innings badge */}
        <div
          className="flex items-center justify-center px-3 py-2"
          style={{ background: c.secondary, minWidth: 80 }}
        >
          <div className="text-center" style={{ color: c.accentText }}>
            <div style={{ fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700, letterSpacing: "0.08em", lineHeight: 1.1 }}>
              {innings.inningsLabel.split(" ")[0]}
            </div>
            <div style={{ fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700, letterSpacing: "0.08em", lineHeight: 1.1 }}>
              {innings.inningsLabel.split(" ").slice(1).join(" ")}
            </div>
          </div>
        </div>
      </div>

      {/* Column headers */}
      <div
        className="grid"
        style={{
          gridTemplateColumns: "3fr 4fr 48px 48px",
          background: c.primary,
          borderBottom: `1px solid ${c.borderColor}`,
          opacity: 0.85,
        }}
      >
        {["BATSMAN", "DISMISSAL", "R", "B"].map((h, i) => (
          <div
            key={i}
            className="py-1 px-2"
            style={{
              color: c.text,
              fontSize: "clamp(8px, 1.2vw, 11px)",
              fontWeight: 700,
              textAlign: i >= 2 ? "center" : i === 1 ? "center" : "left",
              letterSpacing: "0.06em",
              opacity: 0.8,
            }}
          >
            {h}
          </div>
        ))}
      </div>

      {/* Batsmen rows */}
      {batsmen.map((row, idx) => {
        const { left, right } = getDismissalText(row);
        const isOdd = idx % 2 === 0;
        const rowBg = isOdd ? c.rowOdd : c.rowEven;

        return (
          <div
            key={row.player_id}
            className="grid items-center"
            style={{
              gridTemplateColumns: "3fr 4fr 48px 48px",
              background: rowBg,
              borderBottom: `1px solid ${c.borderColor}`,
            }}
          >
            {/* Batsman name */}
            <div className="px-2 py-[5px]">
              {!isExportMode && onPlayerClick ? (
                <button
                  onClick={() => onPlayerClick(row.player_id, row.name)}
                  className="text-left uppercase hover:underline focus:outline-none transition-opacity hover:opacity-80"
                  style={{
                    color: c.rowText,
                    fontSize: "clamp(10px, 1.8vw, 14px)",
                    fontWeight: 700,
                    letterSpacing: "0.04em",
                    background: "none",
                    border: "none",
                    padding: 0,
                    cursor: "pointer",
                  }}
                >
                  {row.name}
                </button>
              ) : (
                <span
                  className="uppercase"
                  style={{
                    color: c.rowText,
                    fontSize: "clamp(10px, 1.8vw, 14px)",
                    fontWeight: 700,
                    letterSpacing: "0.04em",
                  }}
                >
                  {row.name}
                </span>
              )}
            </div>

            {/* Dismissal */}
            <div
              className="px-2 py-[5px] text-center"
              style={{
                color: c.rowText,
                fontSize: "clamp(9px, 1.5vw, 12px)",
                fontWeight: 400,
                opacity: 0.9,
              }}
            >
              {left && (
                <span style={{ fontStyle: row.dismissalType === "not out" ? "italic" : "normal" }}>
                  {left}{" "}
                </span>
              )}
              {right && (
                <span style={{ fontWeight: 600 }}>{right}</span>
              )}
              {!left && !right && (
                <span style={{ opacity: 0.5 }}>—</span>
              )}
            </div>

            {/* Runs */}
            <div
              className="text-center py-[5px]"
              style={{
                color: c.rowText,
                fontSize: "clamp(11px, 2vw, 15px)",
                fontWeight: 800,
              }}
            >
              {row.runs}
            </div>

            {/* Balls */}
            <div
              className="text-center py-[5px]"
              style={{
                color: c.rowText,
                fontSize: "clamp(10px, 1.6vw, 13px)",
                fontWeight: 400,
                opacity: 0.7,
              }}
            >
              {row.balls}
            </div>
          </div>
        );
      })}

      {/* DNB */}
      {dnb.length > 0 && (
        <div
          className="px-2 py-[4px]"
          style={{ background: c.rowEven, borderBottom: `1px solid ${c.borderColor}` }}
        >
          <span style={{ color: c.rowText, fontSize: "clamp(9px, 1.4vw, 12px)", opacity: 0.6, fontStyle: "italic" }}>
            Did not bat: {dnb.map((b) => b.name).join(", ")}
          </span>
        </div>
      )}

      {/* Totals row */}
      <div
        className="grid items-center"
        style={{
          gridTemplateColumns: "1fr 1fr 1fr",
          background: c.totalBg,
          borderTop: `2px solid ${c.secondary}`,
          padding: "6px 8px",
        }}
      >
        <div style={{ color: c.totalText, fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 700 }}>
          OVERS {innings.overs}
        </div>
        <div className="text-center" style={{ color: c.totalText, fontSize: "clamp(9px, 1.5vw, 12px)", fontWeight: 400 }}>
          EXTRAS {extras.total}
          {extrasParts.length > 0 && (
            <span style={{ opacity: 0.7, fontSize: "clamp(7px, 1.1vw, 10px)" }}>
              {" "}({extrasParts.join(" ")})
            </span>
          )}
        </div>
        <div
          className="text-right"
          style={{
            color: c.totalText,
            fontSize: "clamp(16px, 3vw, 24px)",
            fontWeight: 900,
            letterSpacing: "0.02em",
          }}
        >
          {innings.total}
        </div>
      </div>
    </div>
  );
}
