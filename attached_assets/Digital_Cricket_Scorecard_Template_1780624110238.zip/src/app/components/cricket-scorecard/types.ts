export interface TeamColors {
  primary: string;    // main header background
  secondary: string;  // accent / innings badge bg
  text: string;       // header text color
  accentText: string; // innings badge text
  rowOdd: string;     // odd row bg
  rowEven: string;    // even row bg
  rowText: string;    // row text
  totalBg: string;    // totals row bg
  totalText: string;  // totals row text
  borderColor: string;
}

export interface BatsmanRow {
  player_id: string;
  name: string;
  dismissalType?: "b" | "c" | "run out" | "lbw" | "hit wicket" | "ret hurt" | "not out" | "retired" | "obstructing" | "timed out";
  catcher?: string;        // fielder who caught
  catcher_id?: string;
  bowler?: string;
  bowler_id?: string;
  runs: number;
  balls: number;
  fours?: number;
  sixes?: number;
  strikeRate?: number;
  dnb?: boolean;           // did not bat
}

export interface BowlerRow {
  player_id: string;
  name: string;
  overs: number;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
  wides?: number;
  noBalls?: number;
}

export interface Extras {
  total: number;
  byes?: number;
  legByes?: number;
  wides?: number;
  noBalls?: number;
  penaltyRuns?: number;
}

export interface FallOfWicket {
  wicket: number;
  runs: number;
}

export interface InningsData {
  teamName: string;
  teamShortName?: string;
  inningsLabel: string; // "1ST INNINGS", "2ND INNINGS", etc.
  teamColors: TeamColors;
  logoUrl?: string;

  // batting
  batsmen: BatsmanRow[];
  extras: Extras;
  total: number;
  wickets: number;
  overs: number;

  // bowling
  bowlers: BowlerRow[];
  fallOfWickets: FallOfWicket[];
}

export interface ScorecardProps {
  innings: InningsData;
  isExportMode?: boolean;
  onPlayerClick?: (playerId: string, playerName: string) => void;
}
